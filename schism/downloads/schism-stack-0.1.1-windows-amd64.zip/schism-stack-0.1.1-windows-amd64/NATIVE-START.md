# SCHISM native distribution 0.1.1

Extract the complete directory, then run `launch-schism.cmd` to open the local console. With no arguments the launcher opens the console. Supplied arguments pass to the contained controller; for a custom store, supply `--state PATH serve --open`. For a direct command, run `.\schism.exe --help`. Keep `_internal/` beside the executable.

The controller includes its Python runtime. Applications retain their own prerequisites; the included Python examples require an external Python on PATH. Operator state defaults to `~/.schism` outside this directory; use the controller's `--state` option to select another private store.

Platform: windows-amd64. This artifact contains the qualified Windows AMD64 build.

README.md retains the complete product guide, including source-installation instructions. For this native artifact, replace its `python schism.py` command prefix with `.\schism.exe`.

NATIVE-PROVENANCE.json binds the source archive, source manifest, build and native qualification. QUALIFICATION.json is the supplied public projection. ARTIFACT-MANIFEST.json inventories every other file and all directories; the separate archive receipt binds the manifest and complete ZIP. Upstream license texts are retained in native-licenses/. Linux internal symbolic links were safely dereferenced into ordinary files for ZIP portability.
