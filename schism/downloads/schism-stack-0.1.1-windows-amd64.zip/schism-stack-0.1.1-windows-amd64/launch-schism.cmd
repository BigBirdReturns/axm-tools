@echo off
setlocal
if "%1"=="" goto console
"%~dp0schism.exe" %*
exit /b %ERRORLEVEL%
:console
"%~dp0schism.exe" serve --open
exit /b %ERRORLEVEL%
