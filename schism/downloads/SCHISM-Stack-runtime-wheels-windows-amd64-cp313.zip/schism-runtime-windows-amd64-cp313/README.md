# SCHISM Stack offline runtime dependencies

Target: windows-amd64-cp313. Source application minimum: Python 3.11.

These wheels were installed and exercised on 3.13.15 (tags/v3.13.15:4061bc4, Aug  5 2026, 13:05:39) [MSC v.1944 64 bit (AMD64)]. This archive is specific to the target interpreter and platform; another Python ABI requires its matching wheel closure.

From the extracted directory:

    python -m venv .venv
    .venv\Scripts\python.exe -m pip install --no-index --find-links wheels --require-hashes -r requirements.lock

The archive contains dependencies only. SCHISM application source and its acceptance record are distributed separately. It does not install a system interpreter or change a global environment. All upstream wheel files remain exact; license texts are also copied into licenses/. WHEELHOUSE.json identifies every other file. Verify the archive SHA-256 supplied by the release before extraction.
