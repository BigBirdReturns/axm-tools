#!/bin/sh
set -eu
case "$0" in */*) here=${0%/*} ;; *) here=. ;; esac
here=$(CDPATH= cd -- "$here" && pwd)
if [ "$#" -eq 0 ]; then
    exec "$here/schism" serve --open
fi
exec "$here/schism" "$@"
