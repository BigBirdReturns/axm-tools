# SCHISM Stack offline runtime dependencies

Target: linux-x86_64-cp314. Source application minimum: Python 3.11.

These wheels were installed and exercised on 3.14.4 (main, Aug 20 2026, 10:41:58) [GCC 15.2.0]. This archive is specific to the target interpreter and platform; another Python ABI requires its matching wheel closure.

From the extracted directory:

    python -m venv .venv
    .venv/bin/python -m pip install --no-index --find-links wheels --require-hashes -r requirements.lock

The archive contains dependencies only. SCHISM application source and its acceptance record are distributed separately. It does not install a system interpreter or change a global environment. All upstream wheel files remain exact; license texts are also copied into licenses/. WHEELHOUSE.json identifies every other file. Verify the archive SHA-256 supplied by the release before extraction.
