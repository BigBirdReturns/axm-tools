from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import blake3
import duckdb

# In-process Genesis verification (preferred over shelling out)
try:
    from axm_verify.logic import verify_shard as genesis_verify_shard  # type: ignore
except Exception:
    genesis_verify_shard = None  # type: ignore

from .audit import AuditLogger
from .chat import ChatEngine
from .db import SystemCatalog
from .retrieval import Embedder, VectorIndex
from .sqlgate import is_read_only_sql
from .transport import TransportAdapter
from .util import choose_temp_root, quote_ident, sanitize_identifier, sha256_hex


# Genesis v1 core tables: canonical JSONL files with frozen, exact key sets
# (spec/v1/SPECIFICATION.md section 11). byte_start/byte_end/tier are the only
# integer columns; everything else is a string.
_CORE_TABLES: Tuple[Tuple[str, str, Tuple[Tuple[str, str], ...]], ...] = (
    (
        "graph/claims.jsonl",
        "claims",
        (("claim_id", "VARCHAR"), ("subject", "VARCHAR"), ("predicate", "VARCHAR"),
         ("object", "VARCHAR"), ("object_type", "VARCHAR"), ("tier", "BIGINT")),
    ),
    (
        "graph/entities.jsonl",
        "entities",
        (("entity_id", "VARCHAR"), ("namespace", "VARCHAR"),
         ("label", "VARCHAR"), ("entity_type", "VARCHAR")),
    ),
    (
        "graph/provenance.jsonl",
        "provenance",
        (("provenance_id", "VARCHAR"), ("claim_id", "VARCHAR"), ("source_hash", "VARCHAR"),
         ("byte_start", "BIGINT"), ("byte_end", "BIGINT")),
    ),
    (
        "evidence/spans.jsonl",
        "spans",
        (("span_id", "VARCHAR"), ("source_hash", "VARCHAR"),
         ("byte_start", "BIGINT"), ("byte_end", "BIGINT"), ("text", "VARCHAR")),
    ),
)


def _read_jsonl_rows(path: Path) -> List[Dict[str, Any]]:
    """Read one JSON object per line with the stdlib parser.

    Shard tables are canonical JSONL (one canonical-JSON record per line);
    mounting only needs plain parsing — canonical-form enforcement is the
    verifier's job and has already run behind the mount gate.
    """
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{lineno}: invalid JSON line: {e}") from e
            if not isinstance(obj, dict):
                raise ValueError(f"{path}:{lineno}: JSONL row is not an object")
            rows.append(obj)
    return rows


def _duckdb_type_for(value: Any) -> str:
    if isinstance(value, bool):
        return "BOOLEAN"
    if isinstance(value, int):
        return "BIGINT"
    return "VARCHAR"


@dataclass(frozen=True)
class MountSpec:
    mount_id: str
    shard_id: str
    merkle_root: str
    spec_version: str
    source_path: str
    transport: str
    tables: Tuple[str, ...]


class SpectraEngine:
    """Spectra Runtime Kernel.

    v0.3.1 (Strict):
    - Genesis is the only constitution.
    - Clarion is transport only.
    - Every mount runs axm-verify (unless explicit dev override).
    """

    _NAMESPACE = uuid.UUID("3b1c7a74-0f9a-4c61-9cc8-8f2a3f5e0f5f")

    def __init__(
        self,
        *,
        audit_path: Optional[str] = None,
        cache_path: Optional[str] = None,
        db_path: Optional[str] = None,
        temp_root: Optional[str] = None,
        query_threads: Optional[int] = None,
        async_threads: Optional[int] = None,
    ) -> None:
        self._start_time = time.time()
        self._lock = threading.RLock()
        config = {}
        for name, value in (("threads", query_threads), ("async_threads", async_threads)):
            if value is not None:
                if type(value) is not int or not 1 <= value <= 64:
                    raise ValueError(name + " must be an integer from 1 to 64")
                config[name] = value
        self.con = duckdb.connect(":memory:", config=config)
        self._mount_dirs: Dict[str, Path] = {}
        self._mount_specs: Dict[str, MountSpec] = {}
        self._claims: Dict[str, List[Dict[str, Any]]] = {}

        raw_audit = audit_path or os.environ.get("SPECTRA_AUDIT_PATH", "spectra_audit.jsonl")
        raw_cache = cache_path or os.environ.get("SPECTRA_CACHE_PATH", "spectra_cache.jsonl")
        raw_db = db_path or os.environ.get("SPECTRA_DB_PATH", "spectra.db")

        pid = str(os.getpid())
        raw_audit = raw_audit.replace("{pid}", pid)
        raw_cache = raw_cache.replace("{pid}", pid)
        raw_db = raw_db.replace("{pid}", pid)

        self._audit_path = Path(raw_audit).expanduser().resolve(strict=False)
        self._cache_path = Path(raw_cache).expanduser().resolve(strict=False)
        self._db_path = Path(raw_db).expanduser().resolve(strict=False)

        self._audit = AuditLogger(str(self._audit_path))
        self.catalog = SystemCatalog(str(self._db_path))

        if os.environ.get("SPECTRA_CACHE_DEBUG") == "1":
            print(f"[Engine Init] PID: {pid}", file=sys.stderr)
            print(f"[Engine Init] DB Path: {self._db_path}", file=sys.stderr)
            print(f"[Engine Init] Audit Path: {self._audit_path}", file=sys.stderr)
            print(f"[Engine Init] Cache Path: {self._cache_path}", file=sys.stderr)

        # Vector/chat layers are optional derived layers. They are NEVER
        # constructed at boot; mount/query/audit/nlquery must work without
        # them. They are lazily initialized by _ensure_retrieval() /
        # _ensure_chat() only when a semantic-search or chat method is
        # explicitly invoked.
        self._embedder: Optional[Embedder] = None
        self._index: Optional[VectorIndex] = None
        self._chat_engine: Optional[ChatEngine] = None

        self._temp_root_override = temp_root

    def _ensure_retrieval(self) -> VectorIndex:
        """Lazily construct the optional embedding/vector-index layer.

        Only called from explicit semantic-search/indexing entry points.
        The deterministic query path never reaches this.
        """
        with self._lock:
            if self._index is None:
                self._embedder = Embedder(cache_path=str(self._cache_path))
                self._index = VectorIndex(self._embedder)
            return self._index

    def _ensure_chat(self) -> ChatEngine:
        """Lazily construct the optional chat layer.

        Only called from explicit chat entry points. The deterministic
        query path never reaches this.
        """
        with self._lock:
            if self._chat_engine is None:
                self._chat_engine = ChatEngine(engine=self)
            return self._chat_engine

    def _verify_constitution(self, shard_dir: Path) -> None:
        """Enforces Genesis Standard conformance using axm-verify.

        THE HARD GATE: axm-verify MUST pass. No exceptions in production.
        """
        dev_mode = os.environ.get("SPECTRA_DEV_MODE") == "1"

        # Resolve trusted key once for both paths.
        trusted_key_env = os.environ.get("SPECTRA_TRUSTED_PUBKEY")
        if trusted_key_env:
            trusted = Path(trusted_key_env).expanduser().resolve(strict=False)
        else:
            # Local/dev fallback only. Real deployments must pin a trusted publisher key.
            trusted = shard_dir / "sig" / "publisher.pub"
            if not dev_mode:
                print(
                    "[WARNING] SPECTRA_TRUSTED_PUBKEY not set. Falling back to shard's publisher.pub as trusted anchor.",
                    file=sys.stderr,
                )

        # Prefer in-process verification (faster, no subprocess overhead).
        if genesis_verify_shard is not None:
            result = genesis_verify_shard(shard_dir, trusted)
            if result.get("status") != "PASS":
                raise ValueError(f"Constitution check failed (in-process verify): {result}")
            return

        # Fall back to CLI.
        try:
            cmd = ["axm-verify", "shard", str(shard_dir), "--trusted-key", str(trusted)]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
            )
            
            if result.returncode != 0:
                raise ValueError(f"Constitution check failed (axm-verify): {result.stderr or result.stdout}")
            return
                
        except FileNotFoundError:
            pass

        if dev_mode:
            # DEV MODE ONLY: Minimal layout check for local development.
            # This should NEVER be used in production.
            print("[WARNING] axm-verify not found, running in DEV MODE", file=sys.stderr)
            if not (shard_dir / "manifest.json").exists():
                raise ValueError("Constitution check failed: missing manifest.json")
            if not (shard_dir / "sig").exists():
                raise ValueError("Constitution check failed: missing sig/")
            return

        raise ValueError(
            "Constitution check failed: 'axm-verify' not found and in-process verifier unavailable.\n"
            "Install axm-genesis (pip install axm-genesis) or vendor genesis into Spectra."
        )

    def _verify_span_bounds(self, shard_dir: Path, manifest: Dict[str, Any]) -> None:
        """Verify that spans.jsonl byte ranges stay within their referenced content files.

        Reject with PROVENANCE_OUT_OF_BOUNDS if any span exceeds document bounds.
        """
        sources = manifest.get("sources") or []
        hash_to_path: Dict[str, Path] = {}
        for s in sources:
            if not isinstance(s, dict):
                continue
            h = s.get("hash")
            rel = s.get("path")
            if isinstance(h, str) and isinstance(rel, str):
                hash_to_path[h] = (shard_dir / rel)

        spans_path = shard_dir / "evidence" / "spans.jsonl"
        if not spans_path.exists():
            raise ValueError("PROVENANCE_OUT_OF_BOUNDS: missing evidence/spans.jsonl")

        # Precompute file sizes.
        hash_to_size: Dict[str, int] = {}
        for h, fp in hash_to_path.items():
            if not fp.exists():
                raise ValueError(f"PROVENANCE_OUT_OF_BOUNDS: source file missing for hash {h}: {fp}")
            hash_to_size[h] = fp.stat().st_size

        rows = [
            (r.get("source_hash"), r.get("byte_start"), r.get("byte_end"))
            for r in _read_jsonl_rows(spans_path)
        ]

        for source_hash, byte_start, byte_end in rows:
            if not isinstance(source_hash, str) or source_hash not in hash_to_size:
                raise ValueError(f"PROVENANCE_OUT_OF_BOUNDS: unknown source_hash in spans.jsonl: {source_hash}")

            try:
                bs = int(byte_start)
                be = int(byte_end)
            except Exception:
                raise ValueError(
                    f"PROVENANCE_OUT_OF_BOUNDS: non-integer byte range for source_hash {source_hash}: "
                    f"{byte_start}..{byte_end}"
                )

            if bs < 0 or be < 0 or be < bs:
                raise ValueError(
                    f"PROVENANCE_OUT_OF_BOUNDS: invalid byte range for source_hash {source_hash}: {bs}..{be}"
                )

            size = hash_to_size[source_hash]
            if bs > size or be > size:
                raise ValueError(
                    f"PROVENANCE_OUT_OF_BOUNDS: span exceeds source bounds for source_hash {source_hash}: "
                    f"{bs}..{be} (size {size})"
                )

    def _load_table(
        self,
        name: str,
        columns: List[Tuple[str, str]],
        rows: List[Dict[str, Any]],
    ) -> None:
        """(Re)create a DuckDB table and bulk-insert JSONL rows.

        The table is a derived, rebuildable cache held in the engine's DuckDB
        connection — never written into the shard directory.
        """
        col_sql = ", ".join(f"{quote_ident(c)} {t}" for c, t in columns)
        self.con.execute(f"DROP TABLE IF EXISTS {quote_ident(name)}")
        self.con.execute(f"DROP VIEW IF EXISTS {quote_ident(name)}")
        self.con.execute(f"CREATE TABLE {quote_ident(name)} ({col_sql})")
        if rows:
            placeholders = ", ".join("?" for _ in columns)
            data = [[row.get(c) for c, _t in columns] for row in rows]
            self.con.executemany(
                f"INSERT INTO {quote_ident(name)} VALUES ({placeholders})", data
            )

    def boot(self) -> Dict[str, Any]:
        """Rehydrate state from the System Catalog."""
        self.catalog.log_system_event("boot_start")
        active = self.catalog.get_active_mounts()
        results: Dict[str, Any] = {"attempted": len(active), "success": 0, "failed": 0, "details": []}

        print(f"[Boot] Rehydrating {len(active)} mounts from {self._db_path}...", file=sys.stderr)

        for row in active:
            mid = row.get("mount_id")
            try:
                cfg = row.get("mount_config") or {}
                transport = cfg.get("transport")
                if not transport:
                    # Back-compat: treat missing config as genesis.
                    transport = "genesis"

                secret_b64: Optional[str] = None
                if transport == "clarion":
                    if not row.get("enc_secret"):
                        raise ValueError("Missing secret for Clarion transport")
                    secret_b64 = self.catalog.decrypt_secret(row["enc_secret"])

                source_path = row.get("shard_path")
                if not source_path or not Path(source_path).exists():
                    raise ValueError(f"Shard path not found: {source_path}")

                self.mount_shard(
                    source_path,
                    secret_b64,
                    origin="boot",
                    forced_transport=transport,
                )

                results["success"] += 1
                results["details"].append({"mount_id": mid, "status": "ok"})
            except Exception as e:
                if mid:
                    self.catalog.set_mount_error(mid, str(e))
                self.catalog.log_system_event("boot_mount_fail", details={"mount_id": mid, "error": str(e)})
                results["failed"] += 1
                results["details"].append({"mount_id": mid, "status": "error", "msg": str(e)})
                print(f"[Boot] Failed to mount {mid}: {e}", file=sys.stderr)

        self.catalog.log_system_event("boot_complete", details=results)
        return results

    def health(self) -> Dict[str, Any]:
        ok, err = self.catalog.check_health()
        return {
            "status": "online" if ok else "degraded",
            "uptime_sec": int(time.time() - self._start_time),
            "catalog_connected": ok,
            "catalog_error": err,
            "active_mounts": len(self._mount_specs),
            "index_size": self.index_size(),
        }

    def index_size(self) -> int:
        with self._lock:
            if self._index is None:
                return 0
            return self._index.size

    def mount_shard(
        self,
        path: str,
        secret_b64: Optional[str] = None,
        token_hash: Optional[str] = None,
        origin: str = "api",
        forced_transport: Optional[str] = None,
    ) -> MountSpec:
        start_ts = time.time()

        transport = forced_transport or TransportAdapter.detect_format(path)

        target_dir: Path
        temp_dir: Optional[Path] = None

        if transport == "clarion":
            if not secret_b64:
                raise ValueError("Secret required for Clarion transport")

            if self._temp_root_override:
                tr = str(Path(self._temp_root_override).expanduser().resolve(strict=False))
            else:
                tr_path, _ = choose_temp_root()
                tr = str(tr_path)

            target_dir = TransportAdapter.decrypt_envelope(path, secret_b64, temp_root=tr)
            temp_dir = target_dir
        elif transport == "genesis":
            target_dir = Path(path).expanduser().resolve(strict=False)
        else:
            raise ValueError(f"Unknown shard format: {transport}")

        try:
            # Constitution check is mandatory.
            self._verify_constitution(target_dir)

            manifest_path = target_dir / "manifest.json"
            manifest_bytes = manifest_path.read_bytes()
            manifest = json.loads(manifest_bytes.decode("utf-8"))

            spec_version = manifest.get("spec_version")
            if spec_version != "1.0.0":
                raise ValueError(f"Unsupported Genesis spec_version: {spec_version}")

            # Shard identity is DERIVED, never stored (spec section 9):
            #   shard_id = "sh1_" + hex(BLAKE3(manifest_bytes))
            # A manifest that carries a stored shard_id is a v0.x prototype
            # and is rejected by the verify gate above (E_MANIFEST_SCHEMA).
            shard_id = "sh1_" + blake3.blake3(manifest_bytes).hexdigest()

            merkle_root = (manifest.get("integrity") or {}).get("merkle_root")
            if not merkle_root or not isinstance(merkle_root, str):
                raise ValueError("Genesis manifest missing required field: integrity.merkle_root")

            # Additional hard gate: provenance spans must stay within the bounds of their sources.
            self._verify_span_bounds(target_dir, manifest)

            mount_key = json.dumps({"shard_id": shard_id, "merkle_root": merkle_root}, sort_keys=True)
            mount_id = str(uuid.uuid5(self._NAMESPACE, mount_key))
            mount_prefix = mount_id.replace("-", "")[:12]

            with self._lock:
                if mount_id in self._mount_specs:
                    # Drop decrypted bytes from disk if we created them.
                    if temp_dir and temp_dir.exists():
                        shutil.rmtree(temp_dir)
                    return self._mount_specs[mount_id]

                # Load the canonical JSONL tables into DuckDB tables. The
                # loaded tables are a rebuildable query cache that lives in
                # the engine's DuckDB — OUTSIDE the shard directory, which is
                # sealed and never written to (RFC 0002 D2). Remounting
                # rebuilds them from the shard's JSONL bytes.
                tables: List[str] = []
                claims_for_mount: List[Dict[str, Any]] = []

                for rel_path, table_name, columns in _CORE_TABLES:
                    jsonl_path = target_dir / rel_path
                    if not jsonl_path.exists():
                        raise ValueError(f"Genesis shard missing required file: {rel_path}")
                    rows = _read_jsonl_rows(jsonl_path)
                    view_name = f"{table_name}__{mount_prefix}__{sanitize_identifier(shard_id)}"
                    self._load_table(view_name, list(columns), rows)
                    tables.append(view_name)

                # Also mount ext/ tables. Kernel-registry extensions
                # (lineage@1, references@1, temporal@1, locators@1) are
                # canonical JSONL and mount like the core tables. ext/ is
                # opaque to the kernel, so unknown or binary formats are
                # tolerated: skipped with a log line, never a mount failure.
                ext_dir = target_dir / "ext"
                if ext_dir.is_dir():
                    for ext_file in sorted(ext_dir.iterdir()):
                        if not ext_file.is_file():
                            continue
                        if ext_file.suffix != ".jsonl":
                            print(
                                f"[Mount] Skipping opaque ext file (not JSONL): ext/{ext_file.name}",
                                file=sys.stderr,
                            )
                            continue
                        # Extension files follow the `name@version` filename
                        # convention (ext/temporal@1.jsonl). The DuckDB table
                        # name is built from the BASE name only: identifiers
                        # can't contain `@` unquoted, and the union-view
                        # prefix match (ext_temporal__, etc.) keys on the
                        # base name.
                        ext_base = ext_file.stem.split("@", 1)[0]
                        try:
                            ext_rows = _read_jsonl_rows(ext_file)
                        except ValueError as e:
                            print(
                                f"[Mount] Skipping unreadable ext table ext/{ext_file.name}: {e}",
                                file=sys.stderr,
                            )
                            continue
                        if not ext_rows:
                            continue
                        ext_columns = [
                            (k, _duckdb_type_for(ext_rows[0][k])) for k in ext_rows[0].keys()
                        ]
                        view_name = f"ext_{ext_base}__{mount_prefix}__{sanitize_identifier(shard_id)}"
                        self._load_table(view_name, ext_columns, ext_rows)
                        tables.append(view_name)

                # For indexing, pull claim rows as dicts (bounded by shard size in practice).
                claims_view = f"claims__{mount_prefix}__{sanitize_identifier(shard_id)}"
                try:
                    rows = self.con.execute(f"SELECT * FROM {quote_ident(claims_view)}").fetchdf().to_dict("records")
                    for r in rows:
                        if isinstance(r, dict):
                            r.setdefault("shard_id", shard_id)
                            claims_for_mount.append(r)
                except Exception:
                    # Indexing is optional, SQL views remain valid.
                    pass

                spec = MountSpec(
                    mount_id=mount_id,
                    shard_id=shard_id,
                    merkle_root=merkle_root,
                    spec_version=spec_version,
                    source_path=str(path),
                    transport=transport,
                    tables=tuple(sorted(tables)),
                )

                if temp_dir:
                    self._mount_dirs[mount_id] = temp_dir

                self._mount_specs[mount_id] = spec
                self._claims[mount_id] = claims_for_mount

                # Rebuild cross-shard union views so queries can reference
                # bare table names (claims, entities, temporal, lineage, refs)
                # rather than per-shard view names.
                self._rebuild_union_views()

                # Persist to catalog.
                self.catalog.upsert_mount(
                    mount_id=mount_id,
                    doc_id=shard_id,
                    path=str(path),
                    secret=secret_b64,
                    topo_hash=merkle_root,
                    mount_config={"transport": transport},
                )

                if origin == "api":
                    self.catalog.log_system_event("mount_ok", details={"mount_id": mount_id, "transport": transport})

                self._audit.write_event(
                    {
                        "event": "mount_shard",
                        "token_hash": token_hash,
                        "mount_id": mount_id,
                        "shard_id": shard_id,
                        "transport": transport,
                        "tables_created": len(tables),
                        "latency_ms": int((time.time() - start_ts) * 1000),
                    }
                )

                return spec

        except Exception as e:
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir)

            if origin == "api":
                self.catalog.log_system_event("mount_fail", details={"error": str(e), "path": path, "transport": transport})

            raise

    def mount(self, path: str, secret_b64: Optional[str], *, verify: bool = True, token_hash: Optional[str] = None) -> Dict[str, Any]:
        # verify flag remains for API compatibility. Constitution verification always runs.
        spec = self.mount_shard(path, secret_b64, token_hash=token_hash, origin="api")
        return {
            "status": "ok",
            "mount_id": spec.mount_id,
            "shard_id": spec.shard_id,
            "merkle_root": spec.merkle_root,
            "tables": list(spec.tables),
            "transport": spec.transport,
            "verify": {"status": "ok"} if verify else None,
        }

    def _rebuild_union_views(self) -> None:
        """Rebuild cross-shard union views after any mount/unmount.

        Creates bare table names (claims, entities, temporal, lineage, refs,
        provenance, spans) as UNION ALL across all mounted shards.

        nlquery.py references these bare names in JOINs, so they must exist
        and be current whenever shards are added or removed.
        """
        # Core tables — present in every shard
        core_tables = [
            ("claims",     "claims"),
            ("entities",   "entities"),
            ("provenance", "provenance"),
            ("spans",      "spans"),
        ]
        # Ext tables — optional, present only in shards that have them
        ext_tables = [
            ("temporal", "ext_temporal"),
            ("lineage",  "ext_lineage"),
            ("refs",     "ext_references"),
        ]

        all_views = {v for s in self._mount_specs.values() for v in s.tables}

        for bare_name, prefix in core_tables:
            parts = [f'SELECT * FROM {quote_ident(v)}'
                     for v in sorted(all_views)
                     if v.startswith(f"{prefix}__")]
            self.con.execute(f"DROP VIEW IF EXISTS {quote_ident(bare_name)}")
            if parts:
                self.con.execute(
                    f"CREATE VIEW {quote_ident(bare_name)} AS {' UNION ALL '.join(parts)}"
                )

        for bare_name, prefix in ext_tables:
            parts = [f'SELECT * FROM {quote_ident(v)}'
                     for v in sorted(all_views)
                     if v.startswith(f"{prefix}__")]
            self.con.execute(f"DROP VIEW IF EXISTS {quote_ident(bare_name)}")
            if parts:
                self.con.execute(
                    f"CREATE VIEW {quote_ident(bare_name)} AS {' UNION ALL '.join(parts)}"
                )

    def unmount(self, mount_id: str, token_hash: Optional[str] = None) -> None:
        with self._lock:
            spec = self._mount_specs.pop(mount_id, None)
            self._claims.pop(mount_id, None)
            if not spec:
                return

            for t in spec.tables:
                self.con.execute(f"DROP TABLE IF EXISTS {quote_ident(t)}")
                self.con.execute(f"DROP VIEW IF EXISTS {quote_ident(t)}")

            temp_dir = self._mount_dirs.pop(mount_id, None)
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir)

            # Rebuild union views to exclude the unmounted shard
            self._rebuild_union_views()

            self.catalog.set_mount_stopped(mount_id)
            self.catalog.log_system_event("unmount", details={"mount_id": mount_id})
            self._audit.write_event({"event": "unmount", "token_hash": token_hash, "mount_id": mount_id})

    def catalog_json(self) -> Dict[str, Any]:
        with self._lock:
            mounts = []
            for s in sorted(self._mount_specs.values(), key=lambda m: (m.shard_id, m.mount_id)):
                mounts.append(
                    {
                        "mount_id": s.mount_id,
                        "shard_id": s.shard_id,
                        "merkle_root": s.merkle_root,
                        "spec_version": s.spec_version,
                        "transport": s.transport,
                        "tables": list(s.tables),
                    }
                )
            return {"mounts": mounts}

    def query_json(self, sql: str, params: Optional[Sequence[Any]] = None, *, token_hash: Optional[str] = None) -> Dict[str, Any]:
        start = time.perf_counter()
        if not is_read_only_sql(sql):
            raise ValueError("Query rejected. Read-only SQL only.")

        with self._lock:
            res = self.con.execute(sql, list(params)) if params else self.con.execute(sql)
            rows = res.fetchall()
            cols = [d[0] for d in (res.description or [])]

        elapsed_ms = int((time.perf_counter() - start) * 1000)
        self._audit.write_event(
            {
                "event": "sql_query",
                "token_hash": token_hash,
                "sql_hash": sha256_hex(sql)[:16],
                "row_count": len(rows),
                "elapsed_ms": elapsed_ms,
                "active_mounts": sorted(list(self._mount_specs.keys())),
            }
        )
        return {"columns": cols, "rows": rows}

    def index(self, mount_id: Optional[str] = None, token_hash: Optional[str] = None) -> Dict[str, Any]:
        start = time.time()
        with self._lock:
            index = self._ensure_retrieval()
            targets = [mount_id] if mount_id else list(self._claims.keys())
            total_added = 0
            for mid in targets:
                for claim in self._claims.get(mid, []):
                    claim_id = claim.get("claim_id")
                    if not claim_id:
                        continue
                    text = " ".join(
                        str(claim[k])
                        for k in ("subject", "predicate", "object")
                        if claim.get(k) is not None
                    )
                    index.add(str(claim_id), text, metadata={"mount_id": mid, "shard_id": claim.get("shard_id")})
                    total_added += 1

        self._audit.write_event(
            {
                "event": "index_claims",
                "token_hash": token_hash,
                "targets": targets,
                "added_count": total_added,
                "latency_ms": int((time.time() - start) * 1000),
            }
        )
        return {"status": "ok", "indexed": total_added, "index_size": self.index_size()}

    def chat(self, question: str, top_k: int = 7, token_hash: Optional[str] = None) -> Dict[str, Any]:
        # Note: the current ChatEngine does not support top_k; the parameter
        # is accepted for API compatibility but ignored by the stub.
        start = time.time()
        with self._lock:
            chat_engine = self._ensure_chat()
            active_mounts = sorted(list(self._mount_specs.keys()))
            res = chat_engine.ask(question)

        self._audit.write_event(
            {
                "event": "chat_query",
                "token_hash": token_hash,
                "active_mounts": active_mounts,
                "question_hash": sha256_hex(question)[:16],
                "citations_count": len(res.get("citations", [])),
                "latency_ms": int((time.time() - start) * 1000),
            }
        )
        return res
