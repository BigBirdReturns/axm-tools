# Bundled fixture timezone

`America/Los_Angeles` is a 2,852-byte TZif copied from this build environment's `/usr/share/zoneinfo/America/Los_Angeles`. The installed IANA timezone database reports version `2025b` in `/usr/share/zoneinfo/tzdata.zi`. SHA-256: `68977bb9ad6d186fefc6c7abd36010a66e30008dcb2d376087a41c49861e7268`.

IANA timezone data is public domain. Upstream provenance: https://www.iana.org/time-zones and https://data.iana.org/time-zones/releases/tzdata2025b.tar.gz. `timezones.business_zone` first uses the system database, then loads this exact fixture file with Python's standard-library `ZoneInfo.from_file` when no system entry is available. The fallback supports this lab's Los Angeles business policy; arbitrary additional zones require their own timezone data. This supplies the fixture's daylight-saving rules on Windows without a `tzdata` package dependency.
