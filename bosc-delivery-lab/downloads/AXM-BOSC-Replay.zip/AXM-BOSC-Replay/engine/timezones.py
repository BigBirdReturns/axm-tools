"""IANA timezone lookup with a bundled fixture fallback for Windows."""
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def business_zone(key):
    try:
        return ZoneInfo(key)
    except ZoneInfoNotFoundError:
        if key != "America/Los_Angeles":
            raise
        with (Path(__file__).parent / "tzdata" / "America" / "Los_Angeles").open("rb") as stream:
            return ZoneInfo.from_file(stream, key=key)
