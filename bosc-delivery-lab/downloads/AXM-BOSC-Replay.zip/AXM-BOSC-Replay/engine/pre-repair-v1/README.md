# Customer-owned synthetic appointment service

This is executable administrative scheduling software with an intentionally narrow deterministic intake grammar. It is an independent synthetic demonstration inspired by a publicly described delivery category. It does not reproduce BOSC code or establish BOSC's actual internal implementation, performance or defects. The authority is a separate HTTP process with persisted SQLite state. The worker observes customer state through a fresh authenticated GET after a write; an HTTP success body alone never establishes completion.

## Run

Python 3.10+ and its standard library are sufficient. Run from this directory:

```sh
python3 server.py --db /tmp/appointment-lab.sqlite --port 8765 --allow-faults
```

In another process, submit JSON on stdin:

```sh
python3 worker.py --base-url http://127.0.0.1:8765 --token lab-alpha-secret --tenant clinic-alpha --request - <<'JSON'
{"request_id":"demo-book-0001","action":"book","tenant_id":"clinic-alpha","customer_id":"synthetic-customer-01","service_id":"consultation","staff_id":"staff-01","start":"2026-11-09T09:00:00-08:00"}
JSON
```

The worker prints structured transitions and exits 0 for `verified`, 2 for `human_required`. `--journal /absolute/path/journal.jsonl` appends its evidence transitions. Its public Python interface is `worker.run(candidate, worker.Client(base_url, token, timeout=0.5), tenant, journal=None, fault=None)` and returns the same JSON-compatible object. Modules have no import-time process launch.

## Authority API

All `/v1/*` routes require `Authorization: Bearer TOKEN`. Default fixture identity maps `lab-alpha-secret` to `clinic-alpha`, `lab-beta-secret` to `clinic-beta`. These public fixture tokens deliberately support local experiments only. Server and worker restrict ordinary operation to loopback. The database stores separate policy rows for each tenant; the authenticated tenant controls lookup and mutation scope.

| Method/path | Result |
|---|---|
| `GET /health` | Unauthenticated availability and schema |
| `GET /v1/policy` | Authenticated tenant and its policy |
| `GET /v1/appointments/{id}` | Exact current appointment in the authenticated tenant, or 404 |
| `GET /v1/commands/{request_id}` | Persisted immutable command receipt and semantic fingerprint, or 404 |
| `GET /v1/state` | Tenant-scoped appointments, command keys, events, pending outbox and escalations |
| `POST /v1/commands` | Apply a fully specified command transactionally |
| `POST /v1/escalations` | Record `{request_id, reason}` for a human queue |

Strict command schemas reject extra and missing fields. Every command requires `request_id` (8–100 letters, digits, `_` or `-`), `action`, and `tenant_id`. Additional fields:

| Action | Required additional fields |
|---|---|
| `book` | `customer_id`, `service_id`, `staff_id`, `start` |
| `reschedule` | `appointment_id`, `expected_version`, `start` |
| `cancel` | `appointment_id`, `expected_version` |
| `status` | `appointment_id` |

Appointments expose `id`, `tenant_id`, `customer_id`, `service_id`, `staff_id`, UTC `start` and `end`, `status` and positive integer `version`. Generated IDs use `apt-` plus 32 hexadecimal characters. Rescheduling and cancellation require the exact prior version and an active booking. Each successful mutation advances version once. A repeated identical request key returns the retained receipt; changing the command under the same key rejects with 409. The fingerprint covers all input fields except the key. Request IDs live within tenant scope.

Fixture policies allow Monday–Friday 09:00–17:00 America/Los_Angeles, quarter-hour starts, `consultation` (30 minutes), `followup` (15 minutes), `staff-01` and `staff-02`, synthetic customer IDs beginning `synthetic-`. Explicit timezone offsets and whole minutes are required. Time normalization makes equivalent slots comparable. Overlap checks run inside `BEGIN IMMEDIATE`, so concurrent same-staff requests cannot both reserve an overlapping slot. SQLite atomically commits the booking, idempotency receipt, activity event and pending notification outbox row. The outbox records an obligation and does not claim delivery. `status` persists a query receipt without an event or notification.

## Interpretation boundary

```sh
python3 intake.py --request-id transcript-0001 --tenant clinic-alpha 'book consultation with staff-01 for synthetic-customer-01 at 2026-11-09T09:00:00-08:00'
```

`intake.interpret(text, request_id, tenant)` returns either `{state: candidate, candidate: {...}}` or `{state: human_required, reason: ...}`. The exact grammar supports the booking example, `cancel apt-ID version N`, `reschedule apt-ID version N to ISO_DATETIME`, and `status apt-ID`. It performs deterministic full-string parsing. Pass the returned `candidate` into the worker, which performs independent validation. Ambiguous phrases, multiple intentions, medical advice, unknown operations and appended instructions escalate. No speech recognition or language model operates in this module.

## Deliberate failure experiments

The server must start with `--allow-faults`; then worker `--fault NAME` adds `X-Lab-Fault`. Without the flag the server rejects fault injection. These are explicitly injected lab faults, not findings about an external business.

| Fault | Injected behavior | Expected worker behavior |
|---|---|---|
| `success_no_write` | Returns an accepted callback while rolling back all state | `human_required`, reason `success_unsubstantiated_no_authoritative_receipt` |
| `timeout_after_commit` | Commits atomically then delays response 1.5 seconds | Worker timeout 0.5 seconds; recover retained receipt and exact current state; `verified` |
| `partial_failure` | Fails after booking write before receipt and transaction commit | Full rollback; `human_required`; retry same request without fault can execute once |
| `stale_read` | First appointment GET after mutation returns previous/synthetic stale version | Record mismatch; bounded second/third read can establish current exact state |

The worker never derives a fresh request key after uncertainty. A subsequent identical run reconciles the retained key first. It escalates if an earlier outcome has since been superseded by another operation because it cannot truthfully attest that the old intended state remains current. A permanent stale or unavailable authority exhausts bounded verification and requires a human. These mechanisms cover transport uncertainty and common consistency errors; the database authority remains a trust boundary and a compromised authority could fabricate both write and read responses.

## Customer-owned handover

```sh
python3 handover.py export --db /tmp/appointment-lab.sqlite --directory /tmp/appointment-handover
python3 handover.py import --directory /tmp/appointment-handover --db /tmp/restored-authority.sqlite
python3 server.py --db /tmp/restored-authority.sqlite --port 8766
```

Export uses SQLite's backup API for a consistent snapshot, then records schema, row counts and SHA-256. Import checks digest, database integrity and manifest counts, and refuses an existing destination. The snapshot preserves appointments, policies, idempotency keys, receipts, activity, outbox and escalations. It contains both synthetic fixture tenants and is intended for the owner of the whole fixture authority. The digest detects accidental modification; it does not supply a signature or external authenticity. File access controls and production identity belong to an actual deployment. A restarted worker can verify a retained request against the restored authority without recreating the booking.

## Deliberate scope

This lab proves a bounded scheduling transaction and handover mechanism using synthetic data. It does not benchmark language understanding, telephone reliability, clinical decisions, notification delivery, cryptographic identity, commercial cost, real customer retention, or production security. The worker checks candidate authorization against the supplied fixture tenant credential; callers must not expose either fixture token as a real identity system. Policy administration is customer-owned database state, not a public mutation endpoint. No person receives a call, email, message or appointment invitation.
