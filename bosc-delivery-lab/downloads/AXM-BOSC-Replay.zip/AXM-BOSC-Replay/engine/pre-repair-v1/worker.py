#!/usr/bin/env python3
"""Administrative request worker: intent, attempted write, independent readback."""
import argparse
import hashlib
import json
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def fingerprint(command):
    return hashlib.sha256(canonical({k: v for k, v in command.items() if k != "request_id"}).encode()).hexdigest()


class HTTPFailure(Exception):
    def __init__(self, status, payload):
        self.status, self.payload = status, payload
        super().__init__(str(payload))


class Client:
    def __init__(self, base_url, token, timeout=0.5):
        parsed = urllib.parse.urlparse(base_url)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"} or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("This synthetic lab only connects to a loopback HTTP authority")
        self.base_url, self.token, self.timeout = base_url.rstrip("/"), token, timeout

    def request(self, method, path, data=None, fault=None):
        headers = {"Authorization": "Bearer " + self.token, "Content-Type": "application/json"}
        if fault:
            headers["X-Lab-Fault"] = fault
        request = urllib.request.Request(self.base_url + path, data=None if data is None else canonical(data).encode(), headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            try:
                payload = json.load(error)
            except ValueError:
                payload = {"error": "unreadable_authority_error"}
            raise HTTPFailure(error.code, payload)


def validate(command, tenant):
    fields = {
        "book": {"request_id", "action", "tenant_id", "customer_id", "service_id", "staff_id", "start"},
        "reschedule": {"request_id", "action", "tenant_id", "appointment_id", "expected_version", "start"},
        "cancel": {"request_id", "action", "tenant_id", "appointment_id", "expected_version"},
        "status": {"request_id", "action", "tenant_id", "appointment_id"},
    }
    if not isinstance(command, dict):
        raise ValueError("candidate_must_be_object")
    action = command.get("action")
    if action not in fields:
        raise ValueError("unsupported_or_ambiguous_action")
    if set(command) != fields[action]:
        raise ValueError("unexpected_or_missing_fields")
    if command["tenant_id"] != tenant:
        raise ValueError("tenant_authorization_mismatch")
    import re
    if not isinstance(command["request_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{8,100}", command["request_id"]):
        raise ValueError("invalid_request_id")
    if any(not isinstance(command[k], str) or not command[k] or len(command[k]) > 150 for k in fields[action] - {"expected_version"}):
        raise ValueError("invalid_string_field")
    if "expected_version" in command and (type(command["expected_version"]) is not int or command["expected_version"] < 1):
        raise ValueError("positive_integer_version_required")


def expected_state(command, policy, existing=None):
    action = command["action"]
    if action == "book":
        if not command["customer_id"].startswith(policy["customer_prefix"]):
            raise ValueError("synthetic_customer_id_required")
        if command["service_id"] not in policy["services"] or command["staff_id"] not in policy["staff"]:
            raise ValueError("unknown_service_or_staff")
        expectation = {k: command[k] for k in ("tenant_id", "customer_id", "service_id", "staff_id")}
        expectation.update(status="booked", version=1)
    else:
        if existing is None or existing.get("tenant_id") != command["tenant_id"]:
            raise ValueError("authoritative_prior_state_unavailable")
        expectation = dict(existing)
        if action == "status":
            return expectation
        if expectation["version"] != command["expected_version"]:
            raise ValueError("version_conflict")
        if expectation["status"] != "booked":
            raise ValueError("appointment_already_cancelled")
        expectation["version"] += 1
        if action == "cancel":
            expectation["status"] = "cancelled"
            return expectation
    try:
        start = datetime.fromisoformat(command["start"].replace("Z", "+00:00"))
    except ValueError:
        raise ValueError("invalid_datetime")
    if start.tzinfo is None or start.second or start.microsecond:
        raise ValueError("explicit_timezone_and_whole_minutes_required")
    local = start.astimezone(ZoneInfo(policy["timezone"]))
    end = local + timedelta(minutes=policy["services"][expectation["service_id"]]["minutes"])
    if local.weekday() not in policy["weekdays"] or local.date() != end.date():
        raise ValueError("outside_business_days")
    if local.strftime("%H:%M") < policy["opens"] or end.strftime("%H:%M") > policy["closes"] or local.minute % 15:
        raise ValueError("outside_business_hours_or_slot_grid")
    expectation["start"] = start.astimezone(timezone.utc).isoformat()
    expectation["end"] = end.astimezone(timezone.utc).isoformat()
    return expectation


def run(command, client, tenant, journal=None, fault=None):
    transitions = []
    request_id = command.get("request_id", "invalid-candidate") if isinstance(command, dict) else "invalid-candidate"
    def record(state, **details):
        event = {"state": state, "request_id": request_id, **details}
        transitions.append(event)
        if journal:
            with open(journal, "a", encoding="utf8") as output:
                output.write(canonical({"at": datetime.now(timezone.utc).isoformat(), **event}) + "\n")
    def escalate(reason, **details):
        recorded = False
        try:
            client.request("POST", "/v1/escalations", {"request_id": str(request_id)[:200], "reason": reason[:200]})
            recorded = True
        except Exception:
            pass
        record("human_required", reason=reason, escalation_recorded=recorded, **details)
        return {"state": "human_required", "reason": reason, "request_id": request_id, "transitions": transitions, **details}
    try:
        validate(command, tenant)
        policy_response = client.request("GET", "/v1/policy")
        if policy_response.get("tenant_id") != tenant:
            return escalate("credential_tenant_mismatch")
        policy = policy_response["policy"]
        fp = fingerprint(command)
        # A previous persisted command must be reconciled before deriving a new mutation.
        prior = None
        try:
            prior = client.request("GET", "/v1/commands/" + urllib.parse.quote(request_id, safe=""))
        except HTTPFailure as error:
            if error.status != 404:
                raise
        if prior and prior.get("fingerprint") != fp:
            return escalate("idempotency_key_reused_with_different_request")
        existing = None
        if command["action"] != "book" and not prior:
            existing = client.request("GET", "/v1/appointments/" + urllib.parse.quote(command["appointment_id"], safe=""))
        if prior:
            # The immutable persisted receipt is the retained prior intention. Still
            # verify its semantic relation to this exact request and current state.
            expected = dict(prior["result"]["appointment"])
            if command["action"] == "book":
                fresh = expected_state(command, policy)
                if any(expected.get(k) != v for k, v in fresh.items()):
                    return escalate("prior_receipt_does_not_match_intention")
            elif expected.get("id") != command["appointment_id"] or expected.get("tenant_id") != tenant:
                return escalate("prior_receipt_does_not_match_intention")
            elif command["action"] == "cancel" and (expected.get("status") != "cancelled" or expected.get("version") != command["expected_version"] + 1):
                return escalate("prior_receipt_does_not_match_intention")
            elif command["action"] == "reschedule":
                simulated_prior = dict(expected, status="booked", version=command["expected_version"])
                fresh = expected_state(command, policy, simulated_prior)
                if fresh != expected:
                    return escalate("prior_receipt_does_not_match_intention")
        else:
            expected = expected_state(command, policy, existing)
        record("intention", fingerprint=fp, expected=expected, policy_version=policy["policy_version"], replay=bool(prior))
        if not prior:
            record("attempt", method="POST", path="/v1/commands")
            try:
                client.request("POST", "/v1/commands", command, fault)
            except (TimeoutError, socket.timeout, urllib.error.URLError):
                record("attempt", outcome="transport_uncertain_reconcile_same_request")
            except HTTPFailure as error:
                return escalate(error.payload.get("error", "authority_rejected"), http_status=error.status)
        receipt = prior
        for read_attempt in range(3):
            if receipt is None:
                try:
                    receipt = client.request("GET", "/v1/commands/" + urllib.parse.quote(request_id, safe=""))
                except HTTPFailure as error:
                    if error.status != 404:
                        raise
            if receipt is not None:
                break
            time.sleep(0.04)
        if receipt is None:
            return escalate("success_unsubstantiated_no_authoritative_receipt")
        if receipt.get("tenant_id") != tenant or receipt.get("fingerprint") != fp:
            return escalate("receipt_identity_mismatch")
        recorded_state = receipt["result"]["appointment"]
        if any(recorded_state.get(k) != v for k, v in expected.items()):
            return escalate("committed_state_differs_from_intention")
        expected["id"] = recorded_state["id"]
        observed = None
        for read_attempt in range(3):
            observed = client.request("GET", "/v1/appointments/" + urllib.parse.quote(expected["id"], safe=""))
            if observed == expected:
                break
            record("attempt", outcome="readback_mismatch", read_attempt=read_attempt + 1,
                   expected_version=expected["version"], observed_version=observed.get("version"))
            time.sleep(0.04)
        if observed != expected:
            return escalate("authoritative_readback_differs_from_intention", expected=expected, observed=observed)
        record("verified", appointment=observed, verification="independent_authority_get_exact_state", replay=bool(prior))
        return {"state": "verified", "request_id": request_id, "fingerprint": fp, "appointment": observed,
                "replayed": bool(prior), "transitions": transitions}
    except ValueError as error:
        return escalate(str(error))
    except HTTPFailure as error:
        return escalate(error.payload.get("error", "authority_read_failed"), http_status=error.status)
    except (TimeoutError, socket.timeout, urllib.error.URLError):
        return escalate("authority_unavailable_or_verification_incomplete")
    except (KeyError, TypeError):
        return escalate("authority_response_schema_invalid")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8765")
    parser.add_argument("--token", required=True)
    parser.add_argument("--tenant", required=True)
    parser.add_argument("--request", required=True, help="JSON file, or - for stdin")
    parser.add_argument("--journal")
    parser.add_argument("--fault", choices=["success_no_write", "timeout_after_commit", "partial_failure", "stale_read"])
    parser.add_argument("--timeout", type=float, default=0.5)
    args = parser.parse_args()
    try:
        text = sys.stdin.read() if args.request == "-" else Path(args.request).read_text()
        candidate = json.loads(text)
    except (ValueError, OSError):
        candidate = {"action": "invalid_json"}
    result = run(candidate, Client(args.base_url, args.token, args.timeout), args.tenant, args.journal, args.fault)
    print(json.dumps(result, indent=2))
    return 0 if result["state"] == "verified" else 2


if __name__ == "__main__":
    raise SystemExit(main())
