#!/usr/bin/env python3
"""Deliberately narrow deterministic grammar. No model, speech or clinical advice."""
import argparse
import json
import re
import sys


def interpret(text, request_id, tenant):
    if not isinstance(text, str) or len(text) > 1000:
        return {"state": "human_required", "reason": "unsupported_transcript"}
    base = {"request_id": request_id, "tenant_id": tenant}
    patterns = [
        (r"book (consultation|followup) with (staff-\d{2}) for (synthetic-[A-Za-z0-9_-]+) at (\S+)",
         lambda m: dict(base, action="book", service_id=m[1], staff_id=m[2], customer_id=m[3], start=m[4])),
        (r"cancel (apt-[a-f0-9]{32}) version ([1-9]\d*)", lambda m: dict(base, action="cancel", appointment_id=m[1], expected_version=int(m[2]))),
        (r"reschedule (apt-[a-f0-9]{32}) version ([1-9]\d*) to (\S+)", lambda m: dict(base, action="reschedule", appointment_id=m[1], expected_version=int(m[2]), start=m[3])),
        (r"status (apt-[a-f0-9]{32})", lambda m: dict(base, action="status", appointment_id=m[1])),
    ]
    for pattern, build in patterns:
        match = re.fullmatch(pattern, text.strip())
        if match:
            return {"state": "candidate", "parser": "deterministic_controlled_grammar_v1", "candidate": build(match)}
    return {"state": "human_required", "reason": "ambiguous_or_unsupported_transcript", "parser": "deterministic_controlled_grammar_v1"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--tenant", required=True)
    parser.add_argument("text", nargs="?", help="Controlled transcript; stdin if omitted")
    args = parser.parse_args()
    result = interpret(args.text if args.text is not None else sys.stdin.read(), args.request_id, args.tenant)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["state"] == "candidate" else 2)
