#!/usr/bin/env python3
"""Consistent SQLite backup, digest verification and non-overwriting restoration."""
import argparse
import hashlib
import json
import os
import shutil
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

TABLES = ["policies", "appointments", "commands", "events", "outbox", "escalations"]


def digest(path):
    with open(path, "rb") as stream:
        result = hashlib.file_digest(stream, "sha256") if hasattr(hashlib, "file_digest") else None
        if result is not None:
            return result.hexdigest()
        stream.seek(0)
        return hashlib.sha256(stream.read()).hexdigest()


def inspect(path):
    with sqlite3.connect("file:" + str(path.resolve()) + "?mode=ro", uri=True) as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise ValueError("database_integrity_failed")
        schema = db.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()[0]
        if schema not in {"1", "2"}:
            raise ValueError("unsupported_schema")
        return {"schema_version": int(schema), "row_counts": {table: db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in TABLES}}


def export_database(source, directory):
    source, directory = Path(source), Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    destination = directory / "authority.sqlite"
    with sqlite3.connect("file:" + str(source.resolve()) + "?mode=ro", uri=True) as src, sqlite3.connect(destination) as dest:
        src.backup(dest)
    manifest = {"format": "axm-synthetic-receptionist-handover-v1", "created_at": datetime.now(timezone.utc).isoformat(),
                "database": "authority.sqlite", "sha256": digest(destination), **inspect(destination),
                "scope": "whole authority-owner transfer; all synthetic fixture tenants; not an individual tenant export", "secret_material": False,
                "limitations": "No telephony, clinical advice, production identity, external notification delivery or external integrations."}
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def import_database(directory, destination):
    directory, destination = Path(directory), Path(destination)
    manifest = json.loads((directory / "manifest.json").read_text())
    if manifest.get("format") != "axm-synthetic-receptionist-handover-v1" or manifest.get("database") != "authority.sqlite":
        raise ValueError("unsupported_handover_manifest")
    source = directory / "authority.sqlite"
    if digest(source) != manifest.get("sha256"):
        raise ValueError("handover_digest_mismatch")
    actual = inspect(source)
    if actual["row_counts"] != manifest.get("row_counts") or actual["schema_version"] != manifest.get("schema_version"):
        raise ValueError("handover_manifest_state_mismatch")
    # O_EXCL makes refusal to overwrite hold even if another process races us.
    fd = os.open(destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        with os.fdopen(fd, "wb") as out, source.open("rb") as src:
            shutil.copyfileobj(src, out)
            out.flush()
            os.fsync(out.fileno())
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return {"restored": str(destination), "sha256": digest(destination), **actual}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    export = sub.add_parser("export")
    export.add_argument("--db", required=True)
    export.add_argument("--directory", required=True)
    restore = sub.add_parser("import")
    restore.add_argument("--directory", required=True)
    restore.add_argument("--db", required=True)
    args = parser.parse_args()
    result = export_database(args.db, args.directory) if args.action == "export" else import_database(args.directory, args.db)
    print(json.dumps(result, indent=2))
