#!/usr/bin/env python3
"""Synthetic customer-owned appointment authority; Python 3.10+ stdlib."""
import argparse
import hashlib
import json
import re
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote
from timezones import business_zone

SCHEMA_VERSION = 2
POLICY = {
    "timezone": "America/Los_Angeles", "weekdays": [0, 1, 2, 3, 4],
    "opens": "09:00", "closes": "17:00", "staff": ["staff-01", "staff-02"],
    "services": {"consultation": {"minutes": 30}, "followup": {"minutes": 15}},
    "customer_prefix": "synthetic-", "policy_version": 1,
}
TOKENS = {"lab-alpha-secret": "clinic-alpha", "lab-beta-secret": "clinic-beta"}
CALLER_TOKENS = {
    f"lab-{site}-customer-{number:02}": (f"clinic-{site}", f"synthetic-customer-{number:02}")
    for site in ("alpha", "beta") for number in (1, 2)
}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def fingerprint(command):
    return hashlib.sha256(canonical({k: v for k, v in command.items() if k != "request_id"}).encode()).hexdigest()


def connect(path):
    db = sqlite3.connect(path, timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA busy_timeout=10000")
    return db


def initialize(path):
    with connect(path) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT OR IGNORE INTO metadata VALUES ('schema_version','1');
        CREATE TABLE IF NOT EXISTS policies(tenant_id TEXT PRIMARY KEY, policy_json TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS appointments(
          id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, customer_id TEXT NOT NULL,
          service_id TEXT NOT NULL, staff_id TEXT NOT NULL, start TEXT NOT NULL,
          end TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('booked','cancelled')),
          version INTEGER NOT NULL CHECK(version > 0));
        CREATE INDEX IF NOT EXISTS appointments_scope ON appointments(tenant_id,staff_id,start,end);
        CREATE TABLE IF NOT EXISTS commands(
          tenant_id TEXT NOT NULL, request_id TEXT NOT NULL, fingerprint TEXT NOT NULL,
          result_json TEXT NOT NULL, created_at TEXT NOT NULL,
          PRIMARY KEY(tenant_id,request_id));
        CREATE TABLE IF NOT EXISTS events(
          sequence INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL,
          request_id TEXT NOT NULL, appointment_id TEXT NOT NULL, action TEXT NOT NULL,
          state_json TEXT NOT NULL, created_at TEXT NOT NULL,
          UNIQUE(tenant_id,request_id));
        CREATE TABLE IF NOT EXISTS outbox(
          sequence INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL,
          request_id TEXT NOT NULL, payload_json TEXT NOT NULL,
          delivery_state TEXT NOT NULL DEFAULT 'pending', UNIQUE(tenant_id,request_id));
        CREATE TABLE IF NOT EXISTS escalations(
          id INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL,
          request_id TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
        """)
        for tenant in TOKENS.values():
            db.execute("INSERT OR IGNORE INTO policies VALUES (?,?)", (tenant, canonical(POLICY)))
        version = db.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()[0]
        if version == "1":
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("ALTER TABLE escalations ADD COLUMN candidate_json TEXT NOT NULL DEFAULT 'null'")
                db.execute("ALTER TABLE escalations ADD COLUMN candidate_fingerprint TEXT NOT NULL DEFAULT ''")
                db.execute("UPDATE escalations SET candidate_fingerprint='legacy-' || id")
                db.execute("CREATE UNIQUE INDEX escalation_identity ON escalations(tenant_id,request_id,candidate_fingerprint)")
                db.execute("UPDATE metadata SET value='2' WHERE key='schema_version'")
                db.commit()
            except Exception:
                db.rollback()
                raise
        elif version != str(SCHEMA_VERSION):
            raise ValueError("Unsupported database schema version")


class Rejected(Exception):
    def __init__(self, reason, status=422):
        self.reason, self.status = reason, status


def policy_for(db, tenant):
    row = db.execute("SELECT policy_json FROM policies WHERE tenant_id=?", (tenant,)).fetchone()
    if row is None:
        raise Rejected("tenant_policy_unavailable", 403)
    return json.loads(row[0])


def authorize_customer(state, customer_id):
    if customer_id is not None and state.get("customer_id") != customer_id:
        raise Rejected("caller_ownership_mismatch", 403)


def appointment_for(db, tenant, appt_id, customer_id=None):
    row = db.execute("SELECT * FROM appointments WHERE tenant_id=? AND id=?", (tenant, appt_id)).fetchone()
    if row is None:
        raise Rejected("appointment_not_found", 404)
    state = dict(row)
    authorize_customer(state, customer_id)
    return state


def normalize_start(value, policy, service):
    if not isinstance(value, str):
        raise Rejected("start_must_be_an_offset_datetime")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise Rejected("invalid_datetime")
    if dt.tzinfo is None or dt.second or dt.microsecond:
        raise Rejected("explicit_timezone_and_whole_minutes_required")
    local = dt.astimezone(business_zone(policy["timezone"]))
    end_local = local + timedelta(minutes=policy["services"][service]["minutes"])
    if local.weekday() not in policy["weekdays"] or local.date() != end_local.date():
        raise Rejected("outside_business_days")
    if local.strftime("%H:%M") < policy["opens"] or end_local.strftime("%H:%M") > policy["closes"]:
        raise Rejected("outside_business_hours")
    if local.minute % 15:
        raise Rejected("appointment_must_start_on_quarter_hour")
    return (dt.astimezone(timezone.utc).isoformat(), end_local.astimezone(timezone.utc).isoformat())


def validate_shape(command, tenant):
    if not isinstance(command, dict):
        raise Rejected("command_must_be_object")
    action = command.get("action")
    fields = {
        "book": {"request_id", "action", "tenant_id", "customer_id", "service_id", "staff_id", "start"},
        "reschedule": {"request_id", "action", "tenant_id", "appointment_id", "expected_version", "start"},
        "cancel": {"request_id", "action", "tenant_id", "appointment_id", "expected_version"},
        "status": {"request_id", "action", "tenant_id", "appointment_id"},
    }
    if action not in fields:
        raise Rejected("unsupported_action")
    if set(command) != fields[action]:
        raise Rejected("unexpected_or_missing_fields")
    if command["tenant_id"] != tenant:
        raise Rejected("tenant_authorization_mismatch", 403)
    if not isinstance(command["request_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{8,100}", command["request_id"]):
        raise Rejected("invalid_request_id")
    for key in fields[action] - {"expected_version"}:
        if not isinstance(command[key], str) or not command[key] or len(command[key]) > 150:
            raise Rejected("invalid_string_field")
    if "expected_version" in command and (type(command["expected_version"]) is not int or command["expected_version"] < 1):
        raise Rejected("positive_integer_version_required")


def check_candidate(db, command, tenant, customer_id=None):
    validate_shape(command, tenant)
    policy = policy_for(db, tenant)
    action = command["action"]
    if action == "book":
        authorize_customer(command, customer_id)
        if not command["customer_id"].startswith(policy["customer_prefix"]):
            raise Rejected("synthetic_customer_id_required")
        if command["service_id"] not in policy["services"] or command["staff_id"] not in policy["staff"]:
            raise Rejected("unknown_service_or_staff")
        start, end = normalize_start(command["start"], policy, command["service_id"])
        state = {"id": "apt-" + uuid.uuid4().hex, "tenant_id": tenant,
                 "customer_id": command["customer_id"], "service_id": command["service_id"],
                 "staff_id": command["staff_id"], "start": start, "end": end, "status": "booked", "version": 1}
    else:
        state = appointment_for(db, tenant, command["appointment_id"], customer_id)
        if action == "status":
            return state
        if state["version"] != command["expected_version"]:
            raise Rejected("version_conflict", 409)
        if state["status"] != "booked":
            raise Rejected("appointment_already_cancelled", 409)
        state["version"] += 1
        if action == "cancel":
            state["status"] = "cancelled"
        else:
            state["start"], state["end"] = normalize_start(command["start"], policy, state["service_id"])
    if state["status"] == "booked":
        collision = db.execute("""SELECT id FROM appointments WHERE tenant_id=? AND staff_id=?
           AND status='booked' AND id != ? AND start < ? AND end > ? LIMIT 1""",
           (tenant, state["staff_id"], state["id"], state["end"], state["start"])).fetchone()
        if collision:
            raise Rejected("slot_conflict", 409)
    return state


def execute_command(path, command, tenant, fault=None, approved_policy_version=None, customer_id=None):
    validate_shape(command, tenant)
    fp = fingerprint(command)
    db = connect(path)
    try:
        db.execute("BEGIN IMMEDIATE")
        policy = policy_for(db, tenant)
        if type(approved_policy_version) is not int or approved_policy_version != policy["policy_version"]:
            raise Rejected("approved_policy_version_mismatch", 409)
        bound_fp = hashlib.sha256(canonical({"request_fingerprint": fp, "approved_policy_version": approved_policy_version}).encode()).hexdigest()
        prior = db.execute("SELECT * FROM commands WHERE tenant_id=? AND request_id=?", (tenant, command["request_id"])).fetchone()
        if prior:
            if prior["fingerprint"] != fp:
                raise Rejected("idempotency_key_reused_with_different_request", 409)
            result = json.loads(prior["result_json"])
            authorize_customer(result["appointment"], customer_id)
            if result.get("approved_policy_version") != approved_policy_version:
                raise Rejected("prior_receipt_policy_version_mismatch", 409)
            result["replayed"] = True
            db.commit()
            return result
        state = check_candidate(db, command, tenant, customer_id)
        result = {"accepted": True, "replayed": False, "request_id": command["request_id"],
                  "fingerprint": fp, "appointment": state,
                  "approved_policy_version": approved_policy_version, "policy_bound_fingerprint": bound_fp}
        if fault == "success_no_write":
            db.rollback()
            return result
        action = command["action"]
        if action != "status":
            db.execute("""INSERT INTO appointments VALUES (:id,:tenant_id,:customer_id,:service_id,:staff_id,:start,:end,:status,:version)
                ON CONFLICT(id) DO UPDATE SET start=excluded.start,end=excluded.end,status=excluded.status,version=excluded.version""", state)
            if fault == "partial_failure":
                raise Rejected("injected_failure_before_receipt_commit", 503)
        now = datetime.now(timezone.utc).isoformat()
        db.execute("INSERT INTO commands VALUES (?,?,?,?,?)", (tenant, command["request_id"], fp, canonical(result), now))
        if action != "status":
            db.execute("INSERT INTO events(tenant_id,request_id,appointment_id,action,state_json,created_at) VALUES(?,?,?,?,?,?)",
                       (tenant, command["request_id"], state["id"], action, canonical(state), now))
            # An obligation refers to the newest committed state. Preserve older
            # rows for audit but prevent their use as pending notifications.
            for pending in db.execute("SELECT sequence,payload_json FROM outbox WHERE tenant_id=? AND delivery_state='pending'", (tenant,)).fetchall():
                if json.loads(pending["payload_json"])["appointment"]["id"] == state["id"]:
                    db.execute("UPDATE outbox SET delivery_state='superseded' WHERE sequence=?", (pending["sequence"],))
            db.execute("INSERT INTO outbox(tenant_id,request_id,payload_json) VALUES(?,?,?)", (tenant, command["request_id"], canonical({"type": "appointment_changed", "appointment": state})))
        db.commit()
        return result
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


class Authority(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, path, allow_faults=False):
        super().__init__(address, Handler)
        self.db_path, self.allow_faults = path, allow_faults
        self.stale = {}
        self.fault_lock = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    server_version = "SyntheticAppointmentAuthority/1"
    def log_message(self, fmt, *args):
        pass

    def respond(self, status, payload):
        data = canonical(payload).encode()
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def tenant(self):
        token = self.headers.get("Authorization", "").removeprefix("Bearer ")
        self.customer_id = None
        if token in CALLER_TOKENS:
            tenant, self.customer_id = CALLER_TOKENS[token]
            return tenant
        if token not in TOKENS:
            raise Rejected("unauthorized", 401)
        return TOKENS[token]

    def do_GET(self):
        try:
            path = unquote(urlparse(self.path).path)
            if path == "/health":
                return self.respond(200, {"ok": True, "schema_version": SCHEMA_VERSION, "synthetic_only": True})
            tenant = self.tenant()
            with connect(self.server.db_path) as db:
                if path == "/v1/policy":
                    result = {"tenant_id": tenant, "policy": policy_for(db, tenant),
                              "actor": {"role": "caller" if self.customer_id else "staff_admin", "customer_id": self.customer_id}}
                elif path == "/v1/state":
                    if self.customer_id is not None:
                        raise Rejected("staff_admin_required", 403)
                    result = {"tenant_id": tenant,
                        "appointments": [dict(r) for r in db.execute("SELECT * FROM appointments WHERE tenant_id=? ORDER BY id", (tenant,))],
                        "commands": [dict(r) for r in db.execute("SELECT request_id,fingerprint,created_at FROM commands WHERE tenant_id=? ORDER BY request_id", (tenant,))],
                        "events": [dict(r) for r in db.execute("SELECT * FROM events WHERE tenant_id=? ORDER BY sequence", (tenant,))],
                        "outbox": [dict(r) for r in db.execute("SELECT * FROM outbox WHERE tenant_id=? ORDER BY sequence", (tenant,))],
                        "escalations": [dict(r) for r in db.execute("SELECT * FROM escalations WHERE tenant_id=? ORDER BY id", (tenant,))]}
                elif path == "/v1/notifications":
                    notifications = []
                    for row in db.execute("SELECT * FROM outbox WHERE tenant_id=? AND delivery_state='pending' ORDER BY sequence", (tenant,)):
                        payload = json.loads(row["payload_json"])
                        current = appointment_for(db, tenant, payload["appointment"]["id"])
                        if self.customer_id is not None and current["customer_id"] != self.customer_id:
                            continue
                        if payload["appointment"] != current:
                            raise Rejected("pending_notification_state_mismatch", 409)
                        notifications.append({"sequence": row["sequence"], "request_id": row["request_id"],
                                              "delivery_state": row["delivery_state"], "type": payload["type"], "appointment": current})
                    result = {"tenant_id": tenant, "notifications": notifications, "external_delivery": False}
                elif path.startswith("/v1/commands/"):
                    row = db.execute("SELECT * FROM commands WHERE tenant_id=? AND request_id=?", (tenant, path.rsplit("/", 1)[1])).fetchone()
                    if row is None:
                        raise Rejected("command_not_found", 404)
                    result = {"tenant_id": tenant, "request_id": row["request_id"], "fingerprint": row["fingerprint"], "result": json.loads(row["result_json"])}
                    authorize_customer(result["result"]["appointment"], self.customer_id)
                elif path.startswith("/v1/appointments/"):
                    appointment_id = path.rsplit("/", 1)[1]
                    result = appointment_for(db, tenant, appointment_id, self.customer_id)
                    with self.server.fault_lock:
                        stale = self.server.stale.pop((tenant, appointment_id), None)
                    if stale is not None:
                        result = stale
                else:
                    raise Rejected("route_not_found", 404)
            self.respond(200, result)
        except Rejected as error:
            self.respond(error.status, {"error": error.reason})
        except Exception:
            self.respond(500, {"error": "authority_internal_failure"})

    def do_POST(self):
        try:
            tenant = self.tenant()
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > 16384:
                raise Rejected("invalid_request_size", 413)
            try:
                body = json.loads(self.rfile.read(size))
            except (ValueError, UnicodeDecodeError):
                raise Rejected("invalid_json", 400)
            path = urlparse(self.path).path
            if path == "/v1/escalations":
                if not isinstance(body, dict) or set(body) != {"request_id", "reason", "candidate"} or not all(isinstance(body[k], str) and len(body[k]) <= 200 for k in ("request_id", "reason")):
                    raise Rejected("invalid_escalation")
                candidate_json = canonical(body["candidate"])
                candidate_fp = hashlib.sha256(candidate_json.encode()).hexdigest()
                with connect(self.server.db_path) as db:
                    cursor = db.execute("INSERT OR IGNORE INTO escalations(tenant_id,request_id,reason,created_at,candidate_json,candidate_fingerprint) VALUES(?,?,?,?,?,?)", (tenant, body["request_id"], body["reason"], datetime.now(timezone.utc).isoformat(), candidate_json, candidate_fp))
                    replayed = cursor.rowcount == 0
                return self.respond(200 if replayed else 201, {"recorded": True, "tenant_id": tenant, "replayed": replayed, "candidate_fingerprint": candidate_fp})
            if path != "/v1/commands":
                raise Rejected("route_not_found", 404)
            fault = self.headers.get("X-Lab-Fault")
            if fault and (not self.server.allow_faults or fault not in {"success_no_write", "timeout_after_commit", "partial_failure", "stale_read"}):
                raise Rejected("fault_injection_disabled_or_unknown", 403)
            raw_policy_version = self.headers.get("X-Policy-Version", "")
            if not raw_policy_version.isdecimal() or int(raw_policy_version) < 1:
                raise Rejected("approved_policy_version_required", 409)
            approved_policy_version = int(raw_policy_version)
            previous = None
            if fault == "stale_read" and isinstance(body, dict) and "appointment_id" in body:
                with connect(self.server.db_path) as db:
                    previous = appointment_for(db, tenant, body["appointment_id"], self.customer_id)
            result = execute_command(self.server.db_path, body, tenant, fault, approved_policy_version, self.customer_id)
            if fault == "stale_read" and not result["replayed"]:
                current = result["appointment"]
                if previous is None:
                    previous = dict(current)
                    previous["version"] = 0
                    previous["status"] = "unconfirmed"
                with self.server.fault_lock:
                    self.server.stale[(tenant, current["id"])] = previous
            if fault == "timeout_after_commit" and not result["replayed"]:
                time.sleep(1.5)
            self.respond(200, result)
        except Rejected as error:
            self.respond(error.status, {"error": error.reason})
        except (ValueError, TypeError):
            self.respond(400, {"error": "invalid_request"})
        except Exception:
            self.respond(500, {"error": "authority_internal_failure"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", required=True)
    parser.add_argument("--host", default="127.0.0.1", choices=["127.0.0.1", "localhost"])
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--allow-faults", action="store_true")
    args = parser.parse_args()
    initialize(args.db)
    server = Authority((args.host, args.port), args.db, args.allow_faults)
    print(canonical({"listening": f"http://127.0.0.1:{server.server_port}", "db": args.db, "synthetic_only": True}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
