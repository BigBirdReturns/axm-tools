#!/usr/bin/env python3
"""Verify public replay payload hashes and retained source/report bindings."""
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def main():
    manifest = json.loads((ROOT / "PUBLIC-MANIFEST.json").read_text(encoding="utf-8"))
    problems = []
    files = manifest.get("files", [])
    expected_paths = {"PUBLIC-MANIFEST.json"}
    for row in files:
        relative = row["path"]
        path = (ROOT / relative).resolve()
        if relative in expected_paths or Path(relative).is_absolute() or not path.is_relative_to(ROOT):
            problems.append("Invalid or duplicate payload path: " + relative)
            continue
        expected_paths.add(relative)
        if not path.is_file():
            problems.append("Missing payload: " + relative)
        elif path.stat().st_size != row["bytes"] or digest(path) != row["sha256"]:
            problems.append("Payload differs: " + relative)
    inventory = (ROOT / "ARCHIVE-INVENTORY.txt").read_text(encoding="utf-8").splitlines()
    if inventory != sorted(expected_paths):
        problems.append("Archive inventory differs from manifest payload plus manifest")
    engine = ROOT / "engine"
    frozen = json.loads((engine / "source-manifest.json").read_text(encoding="utf-8"))
    if hashlib.sha256(canonical(frozen["files"])).hexdigest() != frozen["aggregate_sha256"]:
        problems.append("Frozen engine aggregate does not match its original manifest")
    if frozen["aggregate_sha256"] != manifest["frozen_engine_aggregate_sha256"]:
        problems.append("Public manifest refers to another frozen engine")
    for relative, row in frozen["files"].items():
        path = engine / relative
        if path.stat().st_size != row["bytes"] or digest(path) != row["sha256"]:
            problems.append("Frozen active source differs: " + relative)
    prior = engine / "pre-repair-v1"
    for relative, expected in json.loads((prior / "source-manifest.json").read_text()).items():
        if digest(prior / relative) != expected:
            problems.append("Historical source differs: " + relative)
    report = json.loads((ROOT / "reports/model-qualification-001.json").read_text(encoding="utf-8"))
    for key, relative in {
        "prompt_sha256": "model/extraction-prompt-v1.txt",
        "fixtures_sha256": "evaluation/model_holdout.json",
        "driver_sha256": "model/qualify.py",
    }.items():
        if digest(ROOT / relative) != report[key]:
            problems.append("Retained model evidence binding differs: " + key)
    prompt_freeze = json.loads((ROOT / "model/prompt-freeze.json").read_text(encoding="utf-8"))
    if prompt_freeze["sha256"] != report["prompt_sha256"]:
        problems.append("Prompt freeze differs from retained report")
    print(json.dumps({"ok": not problems, "payload_files_checked": len(files),
                      "archive_entries": len(inventory),
                      "frozen_engine_aggregate_sha256": frozen["aggregate_sha256"],
                      "retained_model_cases": report["case_count"],
                      "retained_model_passed": report["passed"],
                      "problems": problems}, indent=2))
    return 0 if not problems else 1


if __name__ == "__main__":
    raise SystemExit(main())
