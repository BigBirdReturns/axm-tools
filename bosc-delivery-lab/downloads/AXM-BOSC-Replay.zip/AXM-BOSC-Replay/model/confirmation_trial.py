#!/usr/bin/env python3
"""Replay retained model proposals through explicit synthetic caller confirmation.

No inference calls, expected-answer comparisons, or model/prompt modifications.
All mutations use a separate authority process and the actual worker subprocess.
"""
import argparse
import copy
import hashlib
import json
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from confirmation import (ConfirmationGate, FixtureConfirmationAuthority,
                          TrustedContext, canonical, displayed_proposal, sha256)


ROOT = Path(__file__).resolve().parents[1]


def source_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sqlite_observation(path):
    # Separate read-only connection. Do not reuse worker or authority read responses.
    with sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        return {
            "appointments": [dict(row) for row in db.execute("SELECT * FROM appointments ORDER BY id")],
            "commands": [dict(row) for row in db.execute("SELECT tenant_id,request_id FROM commands ORDER BY tenant_id,request_id")],
            "event_count": db.execute("SELECT COUNT(*) FROM events").fetchone()[0],
            "outbox_count": db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0],
        }


def load_retained(path):
    retained = json.loads(Path(path).read_text())
    cases = {case["id"]: {key: case[key] for key in ("id", "text", "context", "actual")}
             for case in retained["cases"] if case["id"] in ("M01", "M10")}
    if set(cases) != {"M01", "M10"}:
        raise ValueError("Retained M01 and M10 actual proposals are required")
    return cases


def simulate_explicit_caller_approval(authority, candidate, context, transcript, *, ttl_seconds=120):
    # This is an explicit synthetic actor action. It does not inspect any expected
    # answer, accuracy status, or model reasoning. It acknowledges this exact display.
    display = displayed_proposal(candidate, context, transcript)
    approval = authority.confirm_display(display, caller=context.principal(),
                                         decision="approve",
                                         acknowledged_sha256=sha256(canonical(display)),
                                         ttl_seconds=ttl_seconds)
    return display, approval


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, help="New directory; existing directory is refused")
    parser.add_argument("--retained-report", default=str(ROOT / "reports/model-qualification-001.json"))
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {"schema": "model-confirmation-trial-v1", "evidence_class": "executed_synthetic_boundary_trial",
              "started_at_utc": datetime.now(timezone.utc).isoformat(), "cases": [],
              "retained_report_sha256": source_hash(args.retained_report),
              "model_calls": 0, "expected_answers_used": False,
              "boundary": "A trusted fixture separately approves an exact displayed proposal; untrusted retained model output supplies candidate fields only. HMAC binds the display, principal, transcript, request identity, policy version and expiry. This is not production identity or consent certification.",
              "source_hashes": {str(p.relative_to(ROOT)): source_hash(p) for p in [Path(__file__), ROOT / "model/confirmation.py", ROOT / "engine/server.py", ROOT / "engine/worker.py"]}}
    server = None
    server_log = (output / "authority.log").open("w")
    try:
        cases = load_retained(args.retained_report)
        (output / "retained-proposals.json").write_text(json.dumps(cases, indent=2) + "\n")
        with socket.socket() as free:
            free.bind(("127.0.0.1", 0))
            port = free.getsockname()[1]
        base_url = f"http://127.0.0.1:{port}"
        db_path = output / "authority.sqlite"
        server = subprocess.Popen([sys.executable, str(ROOT / "engine/server.py"),
                                   "--db", str(db_path), "--port", str(port)],
                                  stdout=server_log, stderr=subprocess.STDOUT)
        report["authority_process"] = {"pid": server.pid, "base_url": base_url, "database": "authority.sqlite"}
        deadline = time.monotonic() + 8
        while True:
            if server.poll() is not None:
                raise RuntimeError("Authority exited before health check")
            try:
                with urllib.request.urlopen(base_url + "/health", timeout=.3) as response:
                    if response.status == 200:
                        break
            except OSError:
                if time.monotonic() > deadline:
                    raise RuntimeError("Authority did not become ready")
                time.sleep(.05)
        authority = FixtureConfirmationAuthority()
        gate = ConfirmationGate(authority, receipt_db=output / "confirmation.sqlite",
                                worker_path=ROOT / "engine/worker.py", base_url=base_url,
                                evidence_dir=output / "worker-evidence")

        def make_candidate(case_id, request_id):
            case = cases[case_id]
            candidate = copy.deepcopy(case["actual"])
            context = TrustedContext(case["context"]["tenant_id"], case["context"]["customer_id"], request_id)
            candidate.update(request_id=context.request_id, tenant_id=context.tenant_id)
            if candidate.get("action") == "book":
                candidate["customer_id"] = context.customer_id
            return candidate, context, case["text"]

        def record_case(case_id, description, candidate, context, transcript, approval, *, allowed=False, expected_total=0, expected_new_commands=0, expected_reason=None):
            before = sqlite_observation(db_path)
            result = gate.submit(candidate, context=context, transcript=transcript, approval=approval)
            after = sqlite_observation(db_path)
            checks = {
                "worker_invocation_matches_boundary": result["worker_invoked"] == allowed,
                "expected_terminal_state": result["state"] == ("verified" if allowed else "pending_review"),
                "independent_appointment_total": len(after["appointments"]) == expected_total,
                "independent_new_command_count": len(after["commands"]) - len(before["commands"]) == expected_new_commands,
                "blocked_request_preserves_authority": allowed or after == before,
            }
            if expected_reason:
                checks["specific_boundary_reason"] = result["reason"] == expected_reason
            if allowed:
                actual = after["appointments"]
                checks["stored_principal_and_candidate"] = len(actual) == 1 and all(actual[0].get(k) == candidate[k] for k in ("tenant_id", "customer_id", "service_id", "staff_id")) and actual[0]["start"] == "2026-11-09T17:00:00+00:00" and actual[0]["status"] == "booked"
            item = {"id": case_id, "description": description,
                    "candidate": candidate, "context": {**context.principal(), "request_id": context.request_id, "approved_policy_version": context.approved_policy_version},
                    "transcript_sha256": sha256(transcript), "approval_supplied": approval is not None,
                    "result": result, "before_sqlite": before, "after_sqlite": after,
                    "checks": checks, "passed": all(checks.values())}
            report["cases"].append(item)
            (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")

        bad, bad_context, bad_text = make_candidate("M10", "confirmation-m10-0001")
        record_case("C01", "Retained M10 undecided-time proposal, no separate approval", bad, bad_context, bad_text, None,
                    expected_reason="confirmation_missing")
        good, good_context, good_text = make_candidate("M01", "confirmation-m01-0001")
        record_case("C02", "Retained M01 proposal, no separate approval", good, good_context, good_text, None,
                    expected_reason="confirmation_missing")
        display, approval = simulate_explicit_caller_approval(authority, good, good_context, good_text)
        (output / "explicit-simulated-approval.json").write_text(json.dumps({"displayed_candidate": display, "approval": approval, "fixture_action": "Caller explicitly approves this exact displayed proposal; approval is not inferred from model output."}, indent=2) + "\n")
        record_case("C03", "Explicit simulated caller approves exact M01 display; actual worker books", good, good_context, good_text, approval,
                    allowed=True, expected_total=1, expected_new_commands=1)
        changed = {**good, "start": "2026-11-09T10:00:00-08:00"}
        record_case("C04", "Candidate changed after approval", changed, good_context, good_text, approval,
                    expected_total=1, expected_reason="confirmation_display_binding_mismatch")
        other_caller = TrustedContext("clinic-alpha", "synthetic-customer-02", good_context.request_id)
        record_case("C05", "Approved request presented as another caller", {**good, "customer_id": other_caller.customer_id}, other_caller, good_text, approval,
                    expected_total=1, expected_reason="confirmation_principal_mismatch")
        other_tenant = TrustedContext("clinic-beta", "synthetic-customer-01", good_context.request_id)
        record_case("C06", "Approved request presented in another tenant", {**good, "tenant_id": other_tenant.tenant_id}, other_tenant, good_text, approval,
                    expected_total=1, expected_reason="confirmation_principal_mismatch")
        record_case("C07", "Same approved request replay reaches worker and retains one booking", good, good_context, good_text, approval,
                    allowed=True, expected_total=1, expected_new_commands=0)
        _, expired = simulate_explicit_caller_approval(authority, good, good_context, good_text, ttl_seconds=.02)
        time.sleep(.04)
        record_case("C08", "Expired approval blocks worker", good, good_context, good_text, expired,
                    expected_total=1, expected_reason="confirmation_stale")
        record_case("C09", "Transcript changed after approval", good, good_context, good_text + " I have changed my mind.", approval,
                    expected_total=1, expected_reason="confirmation_display_binding_mismatch")
        new_context = TrustedContext(good_context.tenant_id, good_context.customer_id, "confirmation-m01-0002")
        record_case("C10", "Request identity changed after approval", {**good, "request_id": new_context.request_id}, new_context, good_text, approval,
                    expected_total=1, expected_reason="confirmation_display_binding_mismatch")
        forged = copy.deepcopy(approval)
        forged["payload"]["display"] = displayed_proposal(changed, good_context, good_text)
        forged["payload"]["display_sha256"] = sha256(canonical(forged["payload"]["display"]))
        record_case("C11", "Untrusted payload rewrite cannot forge HMAC approval", changed, good_context, good_text, forged,
                    expected_total=1, expected_reason="confirmation_signature_invalid")
        changed_policy = TrustedContext(good_context.tenant_id, good_context.customer_id, good_context.request_id, 2)
        record_case("C12", "Approved policy version changed after approval", good, changed_policy, good_text, approval,
                    expected_total=1, expected_reason="confirmation_display_binding_mismatch")
        with sqlite3.connect(output / "confirmation.sqlite") as receipt_db:
            receipt_db.row_factory = sqlite3.Row
            report["persisted_confirmation_receipts"] = [dict(row) for row in receipt_db.execute("SELECT * FROM receipts ORDER BY receipt_id")]
        launches = output / "worker-evidence/worker-launches.jsonl"
        report["actual_worker_launches"] = [json.loads(line) for line in launches.read_text().splitlines()] if launches.exists() else []
        report["final_independent_sqlite"] = sqlite_observation(db_path)
        report["passed"] = sum(case["passed"] for case in report["cases"])
        report["failed"] = len(report["cases"]) - report["passed"]
        report["verification"] = {"negative_cases_have_durable_pending_receipt": all(any(row["receipt_id"] == case["result"]["receipt_id"] and row["state"] == "pending_review" and row["worker_invoked"] == 0 for row in report["persisted_confirmation_receipts"]) for case in report["cases"] if case["id"] not in ("C03", "C07")),
                                  "exactly_two_actual_worker_processes": len(report["actual_worker_launches"]) == 2,
                                  "one_durable_booking_after_replay": len(report["final_independent_sqlite"]["appointments"]) == 1}
        report["status"] = "pass" if report["failed"] == 0 and all(report["verification"].values()) else "fail"
    except Exception as error:
        report["status"] = "error"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        if server is not None and server.poll() is None:
            server.terminate()
            try:
                server.wait(timeout=3)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait()
        server_log.close()
        report["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"status": report.get("status"), "passed": report.get("passed", 0),
                          "failed": report.get("failed", 0), "report": str(output / "report.json"),
                          "error": report.get("error")}, indent=2))
    return 0 if report.get("status") == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
