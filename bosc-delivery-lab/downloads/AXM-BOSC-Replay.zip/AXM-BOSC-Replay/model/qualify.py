"""One-shot held-out extraction evaluation against an explicitly named local model.

This command sends synthetic test text only. It grants the model no tools, caller
identity, calendar access, or action authority. Raw responses and failed cases
remain in the output. There are no automatic inference retries.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import platform
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize(value):
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items() if v is not None and k != "reason"}
    if isinstance(value, list):
        return [normalize(v) for v in value]
    return value


def score(candidate: dict | None, case: dict) -> tuple[bool, str]:
    if not isinstance(candidate, dict):
        return False, "Response is not a JSON object"
    expected = case.get("expected_candidate", case.get("expected"))
    if expected is None:
        raise ValueError("Each frozen fixture needs expected_candidate or expected")
    if normalize(candidate) != normalize(expected):
        return False, "Candidate differs from frozen expected administrative intent"
    return True, "Exact normalized candidate matches frozen expected intent"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--endpoint", required=True, help="Loopback OpenAI-compatible base URL, such as http://127.0.0.1:18775/v1")
    ap.add_argument("--model", required=True)
    ap.add_argument("--model-description", required=True)
    ap.add_argument("--fixtures", type=Path, required=True)
    ap.add_argument("--prompt", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--timeout", type=float, default=30)
    ap.add_argument("--max-tokens", type=int, default=180)
    args = ap.parse_args()
    u = urllib.parse.urlsplit(args.endpoint)
    if u.scheme != "http" or u.hostname not in {"127.0.0.1", "localhost", "::1"} or u.username or u.password:
        ap.error("Only an explicitly configured unauthenticated loopback HTTP model endpoint is accepted")
    if args.output.exists():
        ap.error("Output already exists; preserve the old run and choose a new path")
    if not 1 <= args.timeout <= 60 or not 32 <= args.max_tokens <= 512:
        ap.error("Inference bounds are timeout 1..60 seconds and max tokens 32..512")
    fixture = json.loads(args.fixtures.read_text(encoding="utf-8"))
    cases = fixture if isinstance(fixture, list) else fixture["cases"]
    if not 1 <= len(cases) <= 100:
        ap.error("A qualification run must have 1..100 explicitly frozen cases")
    prompt = args.prompt.read_text(encoding="utf-8")
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    stream_path = args.output.with_suffix(".jsonl")
    if stream_path.exists():
        ap.error("The retained per-case receipt stream already exists")
    for case in cases:
        user_text = case.get("transcript", case.get("text", case.get("input")))
        if not isinstance(user_text, str):
            raise ValueError("Frozen fixture text must be a string")
        context = case.get("context", fixture.get("context", {}) if isinstance(fixture, dict) else {})
        user = json.dumps({"trusted_context": context, "untrusted_transcript": user_text}, ensure_ascii=False)
        payload = {"model": args.model, "messages": [{"role": "system", "content": prompt}, {"role": "user", "content": user}], "temperature": 0, "seed": 42, "max_tokens": args.max_tokens, "stream": False, "response_format": {"type": "json_object"}}
        row = {"id": case["id"], "text": user_text, "expected": case.get("expected_candidate", case.get("expected")), "context": context, "request_sha256": hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()}
        tick = time.perf_counter()
        try:
            req = urllib.request.Request(args.endpoint.rstrip("/") + "/chat/completions", data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=args.timeout) as response:
                result = json.load(response)
            row["elapsed_ms"] = round((time.perf_counter() - tick) * 1000, 3)
            row["raw_response"] = result
            row["raw_text"] = result["choices"][0]["message"]["content"]
            row["usage"] = result.get("usage")
            row["finish_reason"] = result["choices"][0].get("finish_reason")
            try:
                row["actual"] = json.loads(row["raw_text"])
            except (ValueError, TypeError):
                row["actual"] = None
            passed, reason = score(row["actual"], case)
            row["status"] = "pass" if passed else "fail"
            row["reason"] = reason
        except Exception as exc:
            row["elapsed_ms"] = round((time.perf_counter() - tick) * 1000, 3)
            row["actual"] = None
            row["status"] = "fail"
            row["reason"] = type(exc).__name__ + ": " + str(exc)
        rows.append(row)
        with stream_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(json.dumps({"id": row["id"], "status": row["status"], "elapsed_ms": row["elapsed_ms"], "actual": row["actual"]}), flush=True)
    latencies = sorted(r["elapsed_ms"] for r in rows)
    report = {
        "schema": "axm.model-intent-qualification/1",
        "evidence_class": "observed_local_model_synthetic_holdout",
        "started_at_utc": started,
        "completed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "model": args.model,
        "model_description": args.model_description,
        "runtime": {"python": sys.version, "platform": platform.platform(), "machine": platform.machine()},
        "prompt_sha256": sha(args.prompt),
        "fixtures_sha256": sha(args.fixtures),
        "driver_sha256": sha(Path(__file__)),
        "settings": {"temperature": 0, "seed": 42, "max_tokens": args.max_tokens, "timeout_seconds": args.timeout, "automatic_retries": 0},
        "case_count": len(rows),
        "passed": sum(r["status"] == "pass" for r in rows),
        "failed": sum(r["status"] != "pass" for r in rows),
        "json_objects": sum(isinstance(r["actual"], dict) for r in rows),
        "latency_ms": {"samples": latencies, "median": statistics.median(latencies), "p95_nearest_rank": latencies[max(0, __import__('math').ceil(len(latencies)*.95)-1)]},
        "cases": rows,
        "boundary": "One fixed prompt, separate frozen synthetic fixture set, one sequential request per case. Exact intent extraction only; no speech evaluation or customer state mutation. Reason wording is excluded from exact-match comparison; every other non-null field must match.",
        "residuals": ["No general language reliability inference from this small constructed sample", "Model semantic errors require explicit review or customer confirmation before production action", "Latency includes HTTP round trip and server inference in this environment; it excludes telephony and speech"],
    }
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "passed": report["passed"], "case_count": len(rows)}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
