#!/usr/bin/env python3
"""Explicit synthetic caller approval before model proposals reach the worker.

The signer and authenticated context are trusted fixture inputs. Model JSON has
no reference to the signer, secret, credential selection, or subprocess launcher.
This module proves that boundary locally; it is not production identity proof.
"""
import hashlib
import hmac
import json
import secrets
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path


SCHEMA = "synthetic-caller-confirmation-v1"
FIXTURE_TOKENS = {
    (f"clinic-{site}", f"synthetic-customer-{number:02}"):
    f"lab-{site}-customer-{number:02}"
    for site in ("alpha", "beta") for number in (1, 2)
}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def sha256(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TrustedContext:
    tenant_id: str
    customer_id: str
    request_id: str
    approved_policy_version: int = 1

    def principal(self):
        return {"tenant_id": self.tenant_id, "customer_id": self.customer_id}


def displayed_proposal(candidate, context, transcript):
    """Every authorized field is displayed and bound, including exact transcript hash."""
    return {
        "schema": SCHEMA,
        "candidate": json.loads(canonical(candidate)),
        "tenant_id": context.tenant_id,
        "customer_id": context.customer_id,
        "request_id": context.request_id,
        "approved_policy_version": context.approved_policy_version,
        "transcript_sha256": sha256(transcript),
    }


class FixtureConfirmationAuthority:
    """Separate trusted fixture role; only its public envelopes reach the gate.

    The random HMAC key lives in process memory and is never serialized. A real
    deployment would place this role behind its authenticated confirmation UI.
    """

    def __init__(self):
        self.__secret = secrets.token_bytes(32)
        self.key_id = secrets.token_hex(8)

    def confirm_display(self, displayed, *, caller, decision, acknowledged_sha256, ttl_seconds=120):
        if decision != "approve":
            raise ValueError("explicit_fixture_approval_required")
        if displayed.get("schema") != SCHEMA:
            raise ValueError("invalid_display_schema")
        if caller != {k: displayed.get(k) for k in ("tenant_id", "customer_id")}:
            raise ValueError("caller_does_not_own_display")
        if tuple(caller.get(k) for k in ("tenant_id", "customer_id")) not in FIXTURE_TOKENS:
            raise ValueError("unknown_fixture_caller")
        display_hash = sha256(canonical(displayed))
        if not hmac.compare_digest(acknowledged_sha256, display_hash):
            raise ValueError("display_acknowledgement_mismatch")
        if not 0 < ttl_seconds <= 300:
            raise ValueError("invalid_approval_lifetime")
        now = time.time()
        payload = {
            "schema": SCHEMA,
            "key_id": self.key_id,
            "approval_id": secrets.token_hex(16),
            "principal": dict(caller),
            "decision": "approve",
            "evidence_class": "explicit_trusted_simulated_caller_approval",
            "display": json.loads(canonical(displayed)),
            "display_sha256": display_hash,
            "issued_at_unix": now,
            "expires_at_unix": now + ttl_seconds,
        }
        return {"payload": payload, "signature": hmac.new(self.__secret, canonical(payload).encode(), hashlib.sha256).hexdigest()}

    def verify(self, approval, expected_display, *, now=None):
        if approval is None:
            return "confirmation_missing"
        if not isinstance(approval, dict) or set(approval) != {"payload", "signature"}:
            return "confirmation_envelope_invalid"
        payload, signature = approval["payload"], approval["signature"]
        if not isinstance(payload, dict) or not isinstance(signature, str):
            return "confirmation_envelope_invalid"
        try:
            signed = hmac.new(self.__secret, canonical(payload).encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(signature, signed):
                return "confirmation_signature_invalid"
            if payload.get("schema") != SCHEMA or payload.get("key_id") != self.key_id or payload.get("decision") != "approve":
                return "confirmation_authority_or_decision_invalid"
            issued, expires = payload.get("issued_at_unix"), payload.get("expires_at_unix")
            if type(issued) not in (int, float) or type(expires) not in (int, float) or not 0 < expires - issued <= 300:
                return "confirmation_lifetime_invalid"
            now = time.time() if now is None else now
            if issued > now + 1 or expires <= now:
                return "confirmation_stale"
            principal = {k: expected_display[k] for k in ("tenant_id", "customer_id")}
            if payload.get("principal") != principal:
                return "confirmation_principal_mismatch"
            if payload.get("display") != expected_display or payload.get("display_sha256") != sha256(canonical(expected_display)):
                return "confirmation_display_binding_mismatch"
        except (ValueError, TypeError, KeyError):
            return "confirmation_envelope_invalid"
        return None


class ConfirmationGate:
    def __init__(self, authority, *, receipt_db, worker_path, base_url, evidence_dir):
        self.authority = authority
        self.receipt_db = Path(receipt_db)
        self.worker_path = Path(worker_path)
        self.base_url = base_url
        self.evidence_dir = Path(evidence_dir)
        self.evidence_dir.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.receipt_db) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS receipts(
                receipt_id INTEGER PRIMARY KEY AUTOINCREMENT,
                at_unix REAL NOT NULL, state TEXT NOT NULL, reason TEXT,
                request_id TEXT NOT NULL, tenant_id TEXT NOT NULL,
                customer_id TEXT NOT NULL, candidate_sha256 TEXT NOT NULL,
                transcript_sha256 TEXT NOT NULL, display_sha256 TEXT NOT NULL,
                approval_id TEXT, worker_invoked INTEGER NOT NULL,
                details_json TEXT NOT NULL)""")

    def _record(self, state, reason, candidate, context, display, approval, worker_invoked, details):
        payload = approval.get("payload", {}) if isinstance(approval, dict) else {}
        approval_id = payload.get("approval_id") if isinstance(payload, dict) else None
        with sqlite3.connect(self.receipt_db) as db:
            cur = db.execute("INSERT INTO receipts(at_unix,state,reason,request_id,tenant_id,customer_id,candidate_sha256,transcript_sha256,display_sha256,approval_id,worker_invoked,details_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (
                time.time(), state, reason, context.request_id, context.tenant_id,
                context.customer_id, sha256(canonical(candidate)), display["transcript_sha256"],
                sha256(canonical(display)), approval_id, int(worker_invoked), canonical(details)))
            receipt_id = cur.lastrowid
        return {"state": state, "reason": reason, "receipt_id": receipt_id,
                "request_id": context.request_id, "worker_invoked": worker_invoked, **details}

    def submit(self, candidate, *, context, transcript, approval=None):
        # Snapshot exactly once: another thread changing the original object cannot
        # alter an authorized command between display checking and subprocess input.
        candidate = json.loads(canonical(candidate))
        display = displayed_proposal(candidate, context, transcript)
        reason = None
        if (context.tenant_id, context.customer_id) not in FIXTURE_TOKENS:
            reason = "unknown_fixture_principal"
        elif type(context.approved_policy_version) is not int or context.approved_policy_version < 1:
            reason = "invalid_approved_policy_version"
        elif not isinstance(candidate, dict):
            reason = "candidate_must_be_object"
        elif candidate.get("tenant_id") != context.tenant_id or candidate.get("request_id") != context.request_id:
            reason = "candidate_context_mismatch"
        elif candidate.get("action") == "book" and candidate.get("customer_id") != context.customer_id:
            reason = "candidate_principal_mismatch"
        if reason is None:
            reason = self.authority.verify(approval, display)
        if reason:
            return self._record("pending_review", reason, candidate, context, display, approval, False, {})
        # Persist admission before launch. A later process failure cannot erase the
        # distinction between an approval check and an actual completed operation.
        admitted = self._record("authorized", None, candidate, context, display, approval, False, {})
        worker_args = [sys.executable, str(self.worker_path), "--base-url", self.base_url,
                       "--token", FIXTURE_TOKENS[(context.tenant_id, context.customer_id)],
                       "--tenant", context.tenant_id, "--approved-policy-version",
                       str(context.approved_policy_version), "--request", "-",
                       "--journal", str(self.evidence_dir / "worker-journal.jsonl")]
        prefix = self.evidence_dir / ("worker-" + str(admitted["receipt_id"]))
        try:
            with subprocess.Popen(worker_args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True) as process:
                with (self.evidence_dir / "worker-launches.jsonl").open("a") as log:
                    log.write(canonical({"receipt_id": admitted["receipt_id"], "pid": process.pid,
                                         "request_id": context.request_id, "started_at_unix": time.time()}) + "\n")
                try:
                    stdout, stderr = process.communicate(canonical(candidate), timeout=15)
                except subprocess.TimeoutExpired:
                    process.kill()
                    stdout, stderr = process.communicate()
                    prefix.with_suffix(".stdout.txt").write_text(stdout)
                    prefix.with_suffix(".stderr.txt").write_text(stderr)
                    return self._record("pending_review", "worker_timeout", candidate, context, display, approval, True, {"admission_receipt_id": admitted["receipt_id"], "worker_pid": process.pid})
                prefix.with_suffix(".stdout.txt").write_text(stdout)
                prefix.with_suffix(".stderr.txt").write_text(stderr)
                try:
                    result = json.loads(stdout)
                except ValueError:
                    result = {"state": "unreadable", "stdout": stdout}
                verified = process.returncode == 0 and result.get("state") == "verified"
                return self._record("verified" if verified else "pending_review",
                                    None if verified else "worker_did_not_verify", candidate,
                                    context, display, approval, True,
                                    {"admission_receipt_id": admitted["receipt_id"],
                                     "worker_pid": process.pid, "worker_returncode": process.returncode,
                                     "worker_result": result})
        except OSError as error:
            return self._record("pending_review", "worker_launch_failed", candidate, context, display, approval, False,
                                {"admission_receipt_id": admitted["receipt_id"], "error": str(error)})
