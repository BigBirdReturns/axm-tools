# AXM × BOSC: reproducible delivery lab

This package runs an independent synthetic scheduling implementation inspired by BOSC Tech Labs' publicly described receptionist and agency-delivery workflow. It makes the proposed action, trusted authority, accepted customer state and handover evidence inspectable. BOSC's proprietary software, private customer results and production performance are outside the evidence in this package.

## Run the two demonstrations

Extract the ZIP, open a terminal in `AXM-BOSC-Replay`, and use Python 3.10 or later. The transaction and confirmation replays use the Python standard library, a bundled Los Angeles timezone file and local subprocesses. They require no model server, downloaded model, API key or paid service.

```sh
python -B verify_public.py
python -B run_lab.py --output outputs/acceptance-001
python -B model/confirmation_trial.py --output outputs/confirmation-001
```

Use a new output directory for each run. Existing evidence directories are refused. On systems where the executable is named `python3`, substitute `python3` for `python`.

`run_lab.py` compiles both synthetic intake contracts, launches the independent acceptance runner, and records source identity before and after execution. The frozen contract contains 14 core cases and five mandatory supplementary cases. The runner executes separate authority and worker processes and observes customer state through separate read-only SQLite connections. Its report distinguishes case counts from assertion counts and retains failures. Results appear in `outputs/acceptance-001/acceptance/report.json`; `delivery-run.json` binds the run to its source and criteria.

`confirmation_trial.py` replays the exact retained M01 and M10 proposals from `reports/model-qualification-001.json`. It makes zero inference calls. Twelve cases exercise missing approval, explicit simulated approval, changed candidate, changed caller or tenant, replay, expiry, changed transcript or request identity, forged approval and changed policy version. The report records actual worker launches and independently inspected database state in `outputs/confirmation-001/report.json`.

## The retained semantic finding

The original fixed-prompt model trial produced 16 JSON objects and matched the frozen expected administrative intent in **15 of 16 cases**. M10 supplied two possible times and explicitly said the caller had not chosen. The model nevertheless proposed a 09:00 booking. Its failed observation remains intact in the included report. This small constructed sample measures that specific run; it does not estimate general language reliability.

The confirmation replay preserves that mistaken proposal. Both M10 and the correctly extracted M01 remain pending without a separately approved display. An explicit simulated caller can approve the exact M01 display, after which the real worker executes under a caller-scoped fixture credential and verifies the persisted appointment. The display binds candidate fields, caller, tenant, transcript, request identity, policy version and expiry. Replaying the same approved request retains one booking. Approval supplies a separate decision boundary; approving an incorrect display would still authorize the displayed action.

The retained report identifies the original Qwen3VL-4B-Instruct-Q4_K_M model, its local service alias and execution environment. Its original provenance bytes are preserved. The model weights and original inference service are not included. A new inference run requires your own explicitly configured loopback OpenAI-compatible endpoint. The fixed driver and prompt can be invoked as follows after that service is available:

```sh
python -B model/qualify.py --endpoint http://127.0.0.1:8000/v1 --model YOUR_LOCAL_MODEL --model-description YOUR_MODEL_AND_RUNTIME --fixtures evaluation/model_holdout.json --prompt model/extraction-prompt-v1.txt --output outputs/model-qualification-new.json
```

The output directory must exist for this optional qualification command. Each fixture receives one sequential request; the driver performs no automatic inference retry. The retained report's hashes bind the exact included prompt, holdout and driver. A new model or runtime creates a new observation and does not reproduce the original model's outputs by assumption.

## What the system checks

The authority owns SQLite appointment state. The worker validates a structured proposal against tenant policy, records its intention, attempts the operation and independently reads back exact authoritative state. Persisted request fingerprints reconcile retries after a lost reply. Transactions prevent overlapping reservations and preserve appointments when rescheduling conflicts. Caller ownership, approved policy versions, explicit human escalation and current notification obligations remain separate checks. Deliberate fault cases include a success response without a write, a timeout after commit, stale readback and a failure before transaction commit.

Handover exports a consistent database snapshot with a digest and manifest. Import verifies integrity and refuses to overwrite an existing database. The frozen acceptance suite exercises the restored state in a fresh directory and process, then performs another permitted operation. Transfer covers the owner of the whole synthetic authority and both fixture tenants. See `engine/README.md` for the direct HTTP and worker interfaces.

## Synthetic identity and scope

All tenants, customers, approvals and appointments are fixtures. The public tokens `lab-alpha-secret` and `lab-beta-secret` confer local fixture staff-admin authority. Tokens `lab-alpha-customer-01`, `lab-alpha-customer-02` and their beta equivalents bind specific synthetic callers. These published constants are test inputs, not deployment secrets or production authentication. The confirmation signer uses a disposable in-memory key and a trusted simulated caller; its trial establishes local boundary behavior rather than real identity or consent.

The package performs local administrative scheduling. Notifications remain persisted outbox obligations; nobody receives a call, email, SMS or appointment invitation. Telephony, speech recognition, speech synthesis, external healthcare/calendar integrations, clinical judgment, production scale, financial savings and customer retention remain unmeasured. Test results concern this implementation and these fixtures; they do not compare BOSC's private systems.

## Verify the package

`PUBLIC-MANIFEST.json` records every payload file's size and SHA-256, marks files copied byte-for-byte from the retained implementation, and binds the frozen engine aggregate. `ARCHIVE-INVENTORY.txt` lists every archive entry, including the manifest itself. `verify_public.py` checks the inventory, payload digests, frozen engine manifest, retained pre-repair source hashes and model report bindings. The manifest excludes its own digest to avoid a circular definition; the download's externally supplied ZIP digest binds the whole archive. Hashes establish byte consistency, while provenance and execution results supply separate evidence.

`engine/pre-repair-v1/` preserves the initial implementation as historical source. The active engine is directly under `engine/`. The public package omits private workspace instructions, internal research, existing customer databases and machine-specific execution directories. New runs generate their own local evidence, including runtime details and filesystem locations.
