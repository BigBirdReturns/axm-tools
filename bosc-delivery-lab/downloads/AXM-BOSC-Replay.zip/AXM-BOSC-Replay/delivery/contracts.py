"""Compile an explicit intake into a portable delivery contract, without inference.

The company and approval roles below are simulated. A compiled contract is not a
customer signature, a healthcare authorization, or permission to contact anyone.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def file_digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


REQUIRED = {
    "engagement_id", "customer_label", "data_class", "source_requirements",
    "channels", "supported_operations", "authority", "out_of_scope",
    "success_definition", "handover_definition", "business_baseline",
}


def compile_contract(intake: dict, acceptance_path: Path) -> dict:
    missing = sorted(REQUIRED - intake.keys())
    if missing:
        raise ValueError("Missing intake fields: " + ", ".join(missing))
    if intake["data_class"] != "synthetic_only":
        raise ValueError("This lab accepts synthetic customer data only")
    if intake["authority"].get("scope") != "isolated_local_fixture":
        raise ValueError("The lab contract cannot authorize external actions")
    if not acceptance_path.is_file():
        raise ValueError("Independent acceptance criteria must exist before compilation")
    contract = {
        "schema": "axm.delivery-contract/1",
        "engagement_id": intake["engagement_id"],
        "customer_label": intake["customer_label"],
        "intake_sha256": digest(intake),
        "acceptance_sha256": file_digest(acceptance_path),
        "evidence_tier": "synthetic_customer_contract",
        "approval_status": "SIMULATED_SANDBOX_APPROVAL_ONLY",
        "roles": {
            "channel_partner": "Owns customer relationship and scope; simulated",
            "delivery_pod": "Supplies implementation and delivery receipts; simulated",
            "acceptance_owner": "Supplies criteria and independently observes customer state; simulated",
            "successor_operator": "Receives source, configuration, state, tests, and recovery instructions; simulated",
        },
        "source_requirements": intake["source_requirements"],
        "channels": intake["channels"],
        "supported_operations": intake["supported_operations"],
        "authority": intake["authority"],
        "success_definition": intake["success_definition"],
        "handover_definition": intake["handover_definition"],
        "out_of_scope": intake["out_of_scope"],
        "business_baseline": intake["business_baseline"],
        "change_control": {
            "contract_change": "Changes alter the contract digest and require new acceptance evidence",
            "policy_change": "A candidate prepared against stale policy cannot silently execute",
            "uncertain_execution": "Observe retained authoritative state before retrying the same request identity",
            "rollback": "Restore a verified isolated customer snapshot; preserve prior occurrence receipts",
        },
        "terminal_conditions": {
            "accepted": "The exact implementation, policy, acceptance criteria, and observed results are bound by hashes; all required tests pass",
            "rejected": "Any mandatory check fails; retain failure receipts and prevent acceptance",
            "incomplete": "A requested proof or authorized external integration is absent; report the exact residual",
        },
    }
    supplemental = acceptance_path.with_name("acceptance-supplement-v1.json")
    if supplemental.is_file():
        supplement = json.loads(supplemental.read_text(encoding="utf-8"))
        if supplement["base_contract_sha256"] != contract["acceptance_sha256"]:
            raise ValueError("Supplement refers to a different base acceptance contract")
        contract["acceptance_supplements"] = [{"file": supplemental.name, "sha256": file_digest(supplemental), "required_cases": [case["id"] for case in supplement["cases"]]}]
    contract["contract_sha256"] = digest(contract)
    return contract


def render_brd(contract: dict) -> str:
    lines = [
        "# " + contract["customer_label"] + ": delivery contract",
        "",
        "Synthetic customer engagement. Scope is limited to an isolated local administrative scheduling fixture.",
        "",
        "## Outcome",
        "",
        contract["success_definition"],
        "",
        "## Ownership",
        "",
    ]
    lines += ["- " + role.replace("_", " ").capitalize() + ": " + value for role, value in contract["roles"].items()]
    lines += ["", "## Requirements and provenance", ""]
    for req in contract["source_requirements"]:
        lines.append("- " + req["id"] + ": " + req["requirement"] + " [" + req["evidence_class"] + "] " + req.get("source", ""))
    lines += ["", "## Handover", "", contract["handover_definition"], "", "## Boundaries", ""]
    lines += ["- " + value for value in contract["out_of_scope"]]
    lines += ["", "## Business measurement", "", json.dumps(contract["business_baseline"], indent=2), "", "## Binding", "", "Contract SHA-256: `" + contract["contract_sha256"] + "`", "", "Acceptance source SHA-256: `" + contract["acceptance_sha256"] + "`", ""]
    for supplement in contract.get("acceptance_supplements", []):
        lines += ["Supplement " + supplement["file"] + " SHA-256: `" + supplement["sha256"] + "`", ""]
    return "\n".join(lines)


def verify_event_chain(events: list[dict]) -> dict:
    previous = "0" * 64
    for index, event in enumerate(events):
        body = {key: value for key, value in event.items() if key != "event_sha256"}
        if body.get("previous_sha256") != previous or digest(body) != event.get("event_sha256"):
            return {"ok": False, "failed_index": index}
        previous = event["event_sha256"]
    return {"ok": True, "count": len(events), "frontier": previous}


def append_event(events: list[dict], *, stage: str, status: str, evidence: dict) -> dict:
    event = {
        "sequence": len(events) + 1,
        "stage": stage,
        "status": status,
        "evidence": evidence,
        "previous_sha256": events[-1]["event_sha256"] if events else "0" * 64,
    }
    event["event_sha256"] = digest(event)
    events.append(event)
    return event
