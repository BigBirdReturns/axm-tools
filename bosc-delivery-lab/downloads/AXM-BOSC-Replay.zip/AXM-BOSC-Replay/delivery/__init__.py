"""Delivery contracts for the synthetic, independently verified AXM lab."""
