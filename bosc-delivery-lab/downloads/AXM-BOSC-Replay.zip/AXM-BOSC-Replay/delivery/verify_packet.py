"""Verify a delivery packet against a retained source and evidence manifest.

Hashes prove consistency with the supplied manifest, not the identity or honesty
of its signer. The user retains the canonical manifest with the native run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def validate(root: Path, manifest: dict) -> dict:
    root = root.resolve()
    problems = []
    entries = manifest.get("files", [])
    if not isinstance(entries, list) or not entries:
        return {"ok": False, "checked": 0, "problems": ["Manifest has no file entries"]}
    seen = set()
    for entry in entries:
        rel = entry.get("path", "")
        if rel in seen:
            problems.append({"path": rel, "problem": "duplicate manifest path"})
            continue
        seen.add(rel)
        candidate = (root / rel).resolve()
        if not rel or Path(rel).is_absolute() or not candidate.is_relative_to(root) or candidate == root:
            problems.append({"path": rel, "problem": "invalid relative path"})
            continue
        if not candidate.is_file():
            problems.append({"path": rel, "problem": "missing file"})
            continue
        if candidate.stat().st_size != entry.get("bytes"):
            problems.append({"path": rel, "problem": "size mismatch"})
            continue
        observed = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if observed != entry.get("sha256"):
            problems.append({"path": rel, "problem": "digest mismatch", "observed_sha256": observed})
    return {"ok": not problems, "checked": len(entries), "problems": problems}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--root", type=Path)
    args = parser.parse_args()
    root = args.root or args.manifest.resolve().parent
    result = validate(root, json.loads(args.manifest.read_text(encoding="utf-8")))
    print(json.dumps(result, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
