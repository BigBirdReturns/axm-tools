#!/usr/bin/env python3
"""Reproduce customer acceptance in a new directory, preserving prior receipts."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import signal
import subprocess
import sys
import time
from pathlib import Path

from delivery.contracts import compile_contract, dump, render_brd

ROOT = Path(__file__).resolve().parent


def source_identity() -> dict:
    files = {}
    for path in sorted((ROOT / "engine").rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            files[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    fingerprint = hashlib.sha256(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"sha256": fingerprint, "files": files}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New evidence directory; existing directories are never overwritten")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        parser.error("Output exists. Preserve the previous run and choose a new directory.")
    runner = ROOT / "evaluation/run_acceptance.py"
    if not runner.is_file():
        parser.error("Independent acceptance runner is missing")
    output.mkdir(parents=True)
    acceptance_source = ROOT / "evaluation/acceptance-contract.json"
    for intake_path in sorted((ROOT / "intakes").glob("*.json")):
        contract = compile_contract(json.loads(intake_path.read_text(encoding="utf-8")), acceptance_source)
        dump(output / "contracts" / (intake_path.stem + ".json"), contract)
        (output / "contracts" / (intake_path.stem + ".md")).write_text(render_brd(contract), encoding="utf-8")
    before = source_identity()
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    tick = time.perf_counter()
    command = [sys.executable, str(runner), "--output", str(output / "acceptance")]
    process = subprocess.Popen(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=(os.name == "posix"))
    try:
        stdout, stderr = process.communicate(timeout=180)
        exit_code = process.returncode
    except subprocess.TimeoutExpired as exc:
        exit_code = 124
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            process.terminate()
        try:
            stdout, stderr = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
            stdout, stderr = process.communicate()
        stderr += "\nCustomer acceptance exceeded its 180-second execution bound.\n"
    elapsed = round((time.perf_counter() - tick) * 1000, 3)
    after = source_identity()
    (output / "runner.stdout.log").write_text(stdout, encoding="utf-8")
    (output / "runner.stderr.log").write_text(stderr, encoding="utf-8")
    report = output / "acceptance/report.json"
    stable = before == after
    record = {
        "schema": "axm.delivery-run/1",
        "synthetic_only": True,
        "started_at_utc": started,
        "completed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "runtime": {"python": sys.version, "platform": platform.platform(), "hostname": platform.node()},
        "source_before": before,
        "source_after": after,
        "unchanged_engine": stable,
        "runner_sha256": hashlib.sha256(runner.read_bytes()).hexdigest(),
        "acceptance_contract_sha256": hashlib.sha256(acceptance_source.read_bytes()).hexdigest(),
        "runner_exit_code": exit_code,
        "elapsed_ms": elapsed,
        "acceptance_report": "acceptance/report.json" if report.is_file() else None,
        "acceptance_report_sha256": hashlib.sha256(report.read_bytes()).hexdigest() if report.is_file() else None,
        "state": "completed" if exit_code == 0 and stable and report.is_file() else "failed",
        "meaning": "This record proves a finished local execution and binds its evidence. The acceptance report defines each case verdict. Model interpretation is qualified separately.",
    }
    dump(output / "delivery-run.json", record)
    print(json.dumps({"state": record["state"], "output": str(output), "runner_exit_code": exit_code, "elapsed_ms": elapsed, "engine_sha256": before["sha256"], "unchanged_engine": stable}, indent=2))
    if stdout:
        print(stdout[-4000:])
    if stderr:
        print(stderr[-2000:], file=sys.stderr)
    return 0 if record["state"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
