# Manzanita Works v1.1.0

A public-safe, standalone photographic front door for the connected household-to-region estate.

Open `index.html` directly or use the GitHub Pages surface. The one-file application connects Household Habitat, Street Glide, the Regional Observatory, Civic Planner, Manzanita Works, and Essential Attention through one coordinated reference world.

## What is inside

- seven scales: Plant, Household, Property, Street, Neighborhood, Region, Stewardship;
- eight separately controlled overlays: habitat, shade and heat, water, fire, air, access, labor and tools, authority and programs;
- five functional perspectives: resident, nursery or grower, crew or property steward, planner or public program, successor;
- an assistance-first operating sequence and visible purpose firewall;
- a direct handoff to the live Essential Attention FAB Operating Desk;
- no backend, analytics, forms, email, calendar, payment, publication, or other external-effect adapter.

## Evidence boundary

The photographs are coordinated generated reference views of a Southern California foothill world. They are not registered photographs, surveyed measurements, or an official determination about one physical property. Private household records, exact addresses, meeting material, and source correspondence are absent.

## Qualification

`tests/public_contract_test.py` verifies the static contract and exact application identity. `tests/browser_test.py` drives the exact standalone HTML in desktop and mobile Chromium, checks all controls, asserts image completion and mobile containment, and records any JavaScript, console, or outbound-network failure.
