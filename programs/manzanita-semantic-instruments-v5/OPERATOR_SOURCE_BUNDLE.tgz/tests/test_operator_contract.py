#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--operator", type=Path, required=True)
    args = parser.parse_args()
    root = args.operator
    data = json.loads((root / "data.json").read_text(encoding="utf-8"))
    receipt = json.loads((root / "BUILD_RECEIPT.json").read_text(encoding="utf-8"))
    index = (root / "index.html").read_text(encoding="utf-8")
    app = (root / "app.js").read_text(encoding="utf-8")
    style = (root / "style.css").read_text(encoding="utf-8")
    standalone = (root / "OPERATOR_STANDALONE.html").read_text(encoding="utf-8")

    require(receipt["result"] == "PASS", "Operator build receipt is not PASS")
    require(receipt["release"] == "source-adaptive-semantic-v6-operator", "Operator release drifted")
    require(receipt["projection"] == "progressive_disclosure_operator_projection", "Projection class drifted")
    require(receipt["aperture_count"] == 7, "Aperture count drifted")
    require(receipt["instrument_count"] == 8, "Instrument count drifted")
    require(receipt["seat_count"] == 5, "Seat count drifted")
    require(receipt["source_mode_count"] == 5, "Source-mode count drifted")
    require(receipt["asset_count"] == 10, "Asset count drifted")
    require(receipt["semantic_receipt_count"] == 10, "Semantic receipt count drifted")
    require(receipt["semantic_feature_count"] == 32, "Semantic feature count drifted")
    require(receipt["standalone_self_contained"] is True, "Standalone is not self-contained")
    require(receipt["network_requests_required"] == 0, "Operator requires a runtime network request")
    require(receipt["public_route_effect"] == "none", "Operator claims a public route effect")
    require(receipt["canonical_task_count_effect"] == "none", "Operator claims a task-count effect")

    require(set(data["apertures"]) == {"plant", "household", "property", "street", "neighborhood", "region", "stewardship"}, "Aperture IDs drifted")
    require(set(data["instruments"]) == {"care", "shade", "water", "heat", "air", "fire", "access", "assistance"}, "Instrument IDs drifted")
    require(set(data["seats"]) == {"resident", "nursery_grower", "crew_steward", "planner_program", "successor"}, "Seat IDs drifted")
    require(data["operatorProjection"]["public_route_effect"] == "none", "Operator data claims public route effect")
    require(all(key == f"{row['asset_id']}:{row['instrument']}" for key, row in data["registrations"].items()), "Registration key is not exact asset plus instrument")
    require({row["instrument"] for row in data["registrations"].values()} == {"shade", "water", "access"}, "Non-semantic instrument borrowed image geometry")
    require(sum(row["feature_count"] for row in data["registrations"].values()) == 32, "Semantic features drifted")

    for asset in data["assets"].values():
        path = root / asset["path"]
        require(path.is_file(), f"Missing operator asset: {asset['path']}")
        require(sha256(path) == asset["asset_id"], f"Operator asset identity mismatch: {asset['path']}")

    required_html = [
        'id="apertureRail"', 'id="placeStage"', 'id="instrumentRail"', 'id="featureDeck"',
        'id="sourceDialog"', 'id="seatSelect"', 'id="detailPanel"', 'id="exportButton"',
        'Open qualification console', 'ESSENTIAL ATTENTION HANDOFF',
    ]
    for marker in required_html:
        require(marker in index, f"Operator HTML marker is missing: {marker}")

    required_runtime = [
        "window.__MANZANITA_OPERATOR__", "receiptFor(asset,instrument)", "supportedInstruments()",
        "availableModes()", "selected_feature", "manzanita-works/operator-handoff@6", "public:'none'",
        "Local geometry: none", "Value: not fabricated", "No scene-specific interpretation",
    ]
    for marker in required_runtime:
        require(marker in app, f"Operator runtime marker is missing: {marker}")

    forbidden_runtime = ["FIND_EDGES", "Sobel", "gradient", "generic line", "querySelectorAll('[data-instrument]')"]
    for marker in forbidden_runtime:
        require(marker not in app, f"Forbidden operator shortcut is present: {marker}")

    required_style = [".aperture-rail", ".media-frame", ".instrument-rail", ".feature-deck", ".source-dialog", "min-height:44px", "@media(max-width:560px)"]
    for marker in required_style:
        require(marker in style, f"Operator style marker is missing: {marker}")

    require('src="app.js"' not in standalone, "Standalone retained external app.js")
    require('href="style.css"' not in standalone, "Standalone retained external style.css")
    require("data:image/" in standalone, "Standalone lacks embedded image assets")
    require("window.MANZANITA_OPERATOR_DATA" in standalone, "Standalone lacks embedded data")
    require(len(standalone.encode("utf-8")) > 4_000_000, "Standalone is unexpectedly small")

    print(json.dumps({
        "result": "PASS",
        "release": receipt["release"],
        "apertures": receipt["aperture_count"],
        "instruments": receipt["instrument_count"],
        "seats": receipt["seat_count"],
        "assets": receipt["asset_count"],
        "semantic_receipts": receipt["semantic_receipt_count"],
        "semantic_features": receipt["semantic_feature_count"],
        "standalone_bytes": len(standalone.encode("utf-8")),
        "public_route_effect": receipt["public_route_effect"],
    }, indent=2))


if __name__ == "__main__":
    main()
