#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps
from playwright.sync_api import sync_playwright


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def overflow(page) -> float:
    return page.evaluate("Math.max(document.documentElement.scrollWidth,document.body.scrollWidth)-innerWidth")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--operator", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    url = (args.operator / "index.html").resolve().as_uri()

    states = [
        ("01-household-care-resident", "?ap=household&ins=care&src=reference&seat=resident", 1600, 1000),
        ("02-household-shade-features", "?ap=household&ins=shade&src=reference&seat=resident", 1600, 1000),
        ("03-property-water-planner", "?ap=property&ins=water&src=reference&seat=planner_program", 1600, 1000),
        ("04-street-access-reference", "?ap=street&ins=access&src=reference&seat=crew_steward", 1600, 1000),
        ("05-street-access-live-a", "?ap=street&ins=access&src=live&seat=crew_steward&scene=0", 1600, 1000),
        ("06-street-access-live-b", "?ap=street&ins=access&src=live&seat=crew_steward&scene=1", 1600, 1000),
        ("07-neighborhood-water-withheld", "?ap=neighborhood&ins=water&src=reference&seat=planner_program", 1600, 1000),
        ("08-region-heat-live", "?ap=region&ins=heat&src=live&seat=planner_program", 1600, 1000),
        ("09-region-air-held", "?ap=region&ins=air&src=held&seat=planner_program", 1600, 1000),
        ("10-region-fire-map", "?ap=region&ins=fire&src=map&seat=planner_program", 1600, 1000),
        ("11-stewardship-assistance", "?ap=stewardship&ins=assistance&src=reference&seat=successor", 1600, 1000),
        ("12-mobile-household-water", "?ap=household&ins=water&src=reference&seat=resident", 390, 844),
    ]
    captures = []
    console_errors: list[str] = []
    page_errors: list[str] = []

    with sync_playwright() as pw:
        chromium = Path("/usr/bin/chromium")
        browser = pw.chromium.launch(executable_path=str(chromium) if chromium.exists() else None)
        for name, query, width, height in states:
            context = browser.new_context(viewport={"width": width, "height": height}, color_scheme="dark")
            page = context.new_page()
            page.on("console", lambda message: console_errors.append(message.text) if message.type == "error" else None)
            page.on("pageerror", lambda error: page_errors.append(str(error)))
            page.goto(url + query, wait_until="networkidle")
            page.wait_for_timeout(120)
            path = args.output / f"{name}.png"
            page.screenshot(path=str(path), full_page=False)
            runtime = page.evaluate("window.__MANZANITA_OPERATOR__")
            captures.append({
                "name": name,
                "query": query,
                "viewport": {"width": width, "height": height},
                "horizontal_overflow": overflow(page),
                "state": runtime["state"],
                "asset_id": runtime["asset_id"],
                "receipt_id": runtime["receipt_id"],
                "feature_count": runtime["feature_count"],
                "file": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            })
            context.close()
        browser.close()

    if console_errors or page_errors:
        raise SystemExit(f"Capture errors: console={console_errors}, page={page_errors}")
    if any(row["horizontal_overflow"] > 1 for row in captures):
        raise SystemExit("A captured operator state has horizontal overflow")

    desktop = [row for row in captures if row["viewport"]["width"] > 500]
    thumb_w, thumb_h, label_h = 800, 500, 70
    cols = 2
    rows = (len(desktop) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * thumb_w, rows * (thumb_h + label_h)), "#0d120d")
    draw = ImageDraw.Draw(sheet)
    for index, row in enumerate(desktop):
        with Image.open(args.output / row["file"]) as source:
            frame = ImageOps.fit(source.convert("RGB"), (thumb_w, thumb_h), method=Image.Resampling.LANCZOS)
        x = (index % cols) * thumb_w
        y = (index // cols) * (thumb_h + label_h)
        sheet.paste(frame, (x, y))
        draw.rectangle((x, y + thumb_h, x + thumb_w, y + thumb_h + label_h), fill="#eee8da")
        label = f"{row['state']['aperture'].upper()} · {row['state']['instrument'].upper()} · {row['state']['mode'].upper()} · {row['feature_count']} FEATURES"
        draw.text((x + 16, y + thumb_h + 22), label, fill="#151713")
    contact = args.output / "operator-contact-sheet.jpg"
    sheet.save(contact, quality=92)

    proof_rows = [row for row in captures if row["name"] in {"02-household-shade-features", "03-property-water-planner", "04-street-access-reference", "05-street-access-live-a", "06-street-access-live-b", "07-neighborhood-water-withheld"}]
    proof = Image.new("RGB", (3 * 640, 2 * 470), "#0d120d")
    draw = ImageDraw.Draw(proof)
    for index, row in enumerate(proof_rows):
        with Image.open(args.output / row["file"]) as source:
            frame = ImageOps.fit(source.convert("RGB"), (640, 410), method=Image.Resampling.LANCZOS)
        x = (index % 3) * 640
        y = (index // 3) * 470
        proof.paste(frame, (x, y))
        draw.rectangle((x, y + 410, x + 640, y + 470), fill="#eee8da")
        draw.text((x + 14, y + 428), f"{row['state']['aperture'].upper()} · {row['state']['instrument'].upper()} · {row['feature_count']} FEATURES", fill="#151713")
    semantic = args.output / "operator-semantic-proof.jpg"
    proof.save(semantic, quality=93)

    receipt = {
        "schema": "manzanita-works/operator-capture-receipt@1",
        "release": "source-adaptive-semantic-v6-operator",
        "result": "PASS",
        "captures": captures,
        "contact_sheet": {"file": contact.name, "bytes": contact.stat().st_size, "sha256": sha256(contact)},
        "semantic_proof": {"file": semantic.name, "bytes": semantic.stat().st_size, "sha256": sha256(semantic)},
        "console_errors": console_errors,
        "page_errors": page_errors,
        "public_route_effect": "none",
        "canonical_task_count_effect": "none",
    }
    (args.output / "CAPTURE_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"result": "PASS", "captures": len(captures), "contact_sheet": contact.name, "semantic_proof": semantic.name}, indent=2))


if __name__ == "__main__":
    main()
